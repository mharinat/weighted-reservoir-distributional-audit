using Random,DataStructures,Distributions,WeightVectors,StatsBase
import Base:get
include(joinpath(@__DIR__,"samplers.jl"))
include(joinpath(@__DIR__,"conversion_repair.jl"))
function main()
 open(joinpath(@__DIR__,"conversion-agreement.csv"),"w") do io
 println(io,"N,m,profile,queries,mismatches")
 for N in [4,8,40],m in [2,4],profile in ["uniform","increasing","decreasing"]
  rng=Xoshiro(20261007+N+m);s=ReservoirSampler{Int}(rng,m,AlgWRAExpJ())
  for i in 1:N;add!(s,i,profile=="uniform" ? 1. : profile=="increasing" ? Float64(i) : Float64(N+1-i));end
  a=deepcopy(s);b=deepcopy(s);bad=0
  for k in 1:10000;bad+=copy(get(a))!=copy(get_distinct!(b));end
  println(io,join((N,m,profile,10000,bad),","))
 end
 end
 open(joinpath(@__DIR__,"native-checks.csv"),"w") do io
 println(io,"test,category,count,repetitions")
 R=1000000;s=ReservoirSampler{Int}(Xoshiro(202610071),4,AlgWRAExpJ());for i in 1:4;add!(s,i,1.);end
 counts=Dict{String,Int}()
 for k in 1:R
  x=get(s);key=join(sort([count(==(i),x) for i in 1:4],rev=true),"-");counts[key]=get(counts,key,0)+1
 end
 for key in sort(collect(keys(counts)));println(io,"conversion,",key,",",counts[key],",",R);end
 for (n,p) in [(4,.25),(8,.4),(20,.1)]
  rng=Xoshiro(202610070+n);counts=zeros(Int,n)
  for k in 1:R;counts[choose(rng,n,p)]+=1;end
  for i in 1:n;println(io,"count_",n,"_",p,",",i,",",counts[i],",",R);end
 end
 R=200000;s=ReservoirSampler{Int}(Xoshiro(202610079),4,AlgWRSWRSKIP());add!(s,1,1.);add!(s,2,2.);counts=zeros(Int,5)
 for k in 1:R;x=get(s);@assert length(x)==4 && all(in([1,2]),x);counts[count(==(2),x)+1]+=1;end
 for i in 0:4;println(io,"short_stream,",i,",",counts[i+1],",",R);end
 end
end
main()
