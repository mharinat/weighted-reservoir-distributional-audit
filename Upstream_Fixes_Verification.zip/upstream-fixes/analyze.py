from pathlib import Path
import json,math
import numpy as np,pandas as pd
from scipy.stats import chisquare,binom,norm
P=Path(__file__).resolve().parent;d=pd.read_csv(P/'native-checks.csv');rows=[]
for name,g in d.groupby('test',sort=False):
 n=int(g.repetitions.iloc[0]);counts=g['count'].to_numpy()
 if name=='conversion':
  probs=np.array([{'4-0-0-0':1/64,'3-1-0-0':3/16,'2-2-0-0':9/64,'2-1-1-0':36/64,'1-1-1-1':3/32}[s] for s in g.category]);i=list(g.category).index('2-2-0-0');k=counts[i]
 elif name.startswith('count_'):
  _,m,p=name.split('_');m=int(m);p=float(p);probs=binom.pmf(np.arange(1,m+1),m,p)/binom.sf(0,m,p);k=None
 else:probs=binom.pmf(np.arange(5),4,2/3);k=None
 obs=[];exp=[];a=0;b=0.
 for c,q in zip(counts,probs):
  a+=int(c);b+=n*float(q)
  if b>=5:obs.append(a);exp.append(b);a=0;b=0.
 if b>0:obs[-1]+=a;exp[-1]+=b
 stat,p=chisquare(obs,np.array(exp)*sum(obs)/sum(exp));r={'test':name,'repetitions':n,'chi2':float(stat),'df':len(obs)-1,'p':float(p),'expected_min_after_pooling':min(exp)}
 if k is not None:
  phat=k/n;z=norm.ppf(.975);den=1+z*z/n;mid=(phat+z*z/(2*n))/den;half=z*math.sqrt(phat*(1-phat)/n+z*z/(4*n*n))/den;r.update(event_22=phat,expected_22=9/64,ci95=[mid-half,mid+half],indicator_sd=math.sqrt(n/(n-1)*phat*(1-phat)))
 rows.append(r)
prev=0
for j,r in enumerate(sorted(rows,key=lambda x:x['p'])):prev=max(prev,min(1,(len(rows)-j)*r['p']));r['p_holm']=prev
agree=pd.read_csv(P/'conversion-agreement.csv');res={'date':'2026-10-07','upstream_commit':json.loads((P/'fixes.json').read_text())['sha'],'agreement_queries':int(agree.queries.sum()),'agreement_configurations':len(agree),'agreement_mismatches':int(agree.mismatches.sum()),'distribution_tests':rows,'scope':'Post-submission targeted checks; fixed-reservoir conversion checks; no timing rerun or general correctness certification. Tail bins pooled until expected count >=5; any final remainder merged into last bin. Holm across five tests.'};(P/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
