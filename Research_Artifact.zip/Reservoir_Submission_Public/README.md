# Weighted reservoir sampling: distributional audit

Mohammad Haribat, Independent Researcher, Kuwait. Contact: mharibat@mew.gov.kw.

Research submission prepared for ReScience C; not an accepted publication. This repository contains a partial replication and implementation audit of the public Julia comparison artifact associated with Meligrana and Fazzone, *Weighted Reservoir Sampling with Replacement from Data Streams* (WWW 2026), https://doi.org/10.1145/3774904.3792966 . It does not claim that the formal algorithms or released package are incorrect.

- [Manuscript](Research_Manuscript.pdf) and [editable source](Research_Manuscript.md)
- [Technical supplement](Technical_Supplement.pdf)
- [Reproduction instructions](submission/Reproduce.md)
- [Submission metadata](metadata.yaml)
- `supporting-evidence/`: original source notices, local repairs, synthetic data, exact checks, protocols and analysis scripts

## Reproduce selected analyses

From this repository root, follow `submission/Reproduce.md`. Seven Python scripts regenerate eight checked outputs on a temporary copy. Native Julia experiments and timing measurements are separate procedures. The recorded native environment uses Julia 1.12.1; the recorded Python environment uses Python 3.9.6.

## Scope and provenance

The author reported contacting the original corresponding author on 4 October 2026. Delivery has not been independently verified and no reply has been reported. Private correspondence and internal review documents are excluded. Historic stage numbers describe the sequence of experiments, not alternative current manuscripts. Some historical report tools were excluded; the portable entry point is `submission/replay_selected.py`.

AI assistance was used in code development, analysis and drafting. The author reviewed the manuscript and authorized submission on 5 October 2026 and is responsible for the research.

## Licenses

New software: [MIT](LICENSE-CODE.txt). Original research content and synthetic data: [CC BY 4.0](LICENSE-CONTENT.md). Third-party source retains its original notices.
