"""Strict structure and finite-number checks for decimal analysis CSVs."""
import csv,math
from pathlib import Path

KEYS={
 'followup-summary.csv': ['method'],
 'sweep-summary.csv': ['N','m','pattern','method'],
 'sweep-paired.csv': ['N','m','pattern'],
}
RTOL=1e-9
ATOL=1e-12

def compare_csv(reference,actual):
    reference,actual=Path(reference),Path(actual)
    def read(p):
        with p.open(newline='') as f:
            reader=csv.DictReader(f);header=reader.fieldnames;rows=list(reader)
        if not header or len(header)!=len(set(header)) or any(None in r or any(v is None for v in r.values()) for r in rows):
            raise ValueError('Malformed CSV structure')
        return header,rows
    try:
        h,a=read(reference);j,b=read(actual)
        if h!=j or len(a)!=len(b):raise ValueError('Header or row count differs')
        keys=KEYS[reference.name]
        if not all(k in h for k in keys):raise ValueError('Missing identity columns')
        def index(rows):
            result={tuple(r[k] for k in keys):r for r in rows}
            if len(result)!=len(rows):raise ValueError('Duplicate identities')
            return result
        a,b=index(a),index(b)
        if a.keys()!=b.keys():raise ValueError('Row identities differ')
        maximum=0.0
        for key,row in a.items():
            for col,value in row.items():
                other=b[key][col]
                if col in keys:
                    if value!=other:raise ValueError('Identity differs')
                    continue
                try:x=float(value)
                except ValueError:
                    if value!=other:raise ValueError('Categorical value differs')
                    continue
                try:y=float(other)
                except ValueError:raise ValueError('Numeric value replaced with text')
                if not math.isfinite(x) or not math.isfinite(y):raise ValueError('Non-finite numeric value')
                # Probability tails must not disappear under an absolute tolerance.
                atol=0.0 if col in ('p','p_holm') else ATOL
                delta=abs(x-y);maximum=max(maximum,delta)
                if delta>atol+RTOL*abs(x):raise ValueError('Numeric tolerance exceeded: '+col)
        return {'numerically_agree':True,'max_absolute_difference':maximum,'rtol':RTOL,'atol':ATOL,'probability_atol':0.0}
    except (ValueError,KeyError,OSError) as exc:
        return {'numerically_agree':False,'reason':str(exc)}
