"""Regression checks: rounding differences pass; scientific/schema changes fail."""
import csv,tempfile,unittest
from pathlib import Path
from compare_outputs import compare_csv

class ComparisonTests(unittest.TestCase):
    def run_case(self,rows,header=None):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t)/'sweep-paired.csv';a=Path(t)/'candidate.csv'
            h=['N','m','pattern','mean','p','p_holm'];base=['10000','1000','increasing','0.000236','1e-158','2e-158']
            with r.open('w',newline='') as f:w=csv.writer(f);w.writerow(h);w.writerow(base)
            with a.open('w',newline='') as f:w=csv.writer(f);w.writerow(header or h);w.writerows(rows)
            return compare_csv(r,a)['numerically_agree']
    def row(self,**updates):
        h=['N','m','pattern','mean','p','p_holm'];x=['10000','1000','increasing','0.000236','1e-158','2e-158']
        for k,v in updates.items():x[h.index(k)]=v
        return x
    def test_rounding(self):self.assertTrue(self.run_case([self.row(mean='0.0002360000000001')]))
    def test_material_change(self):self.assertFalse(self.run_case([self.row(mean='0.0003')]))
    def test_probability_underflow_not_masked(self):self.assertFalse(self.run_case([self.row(p='0')]))
    def test_probability_factor_change(self):self.assertFalse(self.run_case([self.row(p='2e-158')]))
    def test_nonfinite(self):
        for x in ['nan','inf','-inf']:self.assertFalse(self.run_case([self.row(mean=x)]))
    def test_missing_row(self):self.assertFalse(self.run_case([]))
    def test_duplicate_row(self):self.assertFalse(self.run_case([self.row(),self.row()]))
    def test_identity_changed(self):self.assertFalse(self.run_case([self.row(pattern='uniform')]))
    def test_schema_changed(self):self.assertFalse(self.run_case([self.row()],['N','m','pattern','mean','p','other']))
if __name__=='__main__':unittest.main()
