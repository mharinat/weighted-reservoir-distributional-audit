"""Replay selected analyses on an isolated copy; never modify supplied evidence."""
from pathlib import Path
import argparse, tempfile, shutil, subprocess, sys, json
from compare_outputs import compare_csv

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    source=root/'supporting-evidence'
    jobs=[('stage3/exact_audit.py',['stage3/exact-audit.json']),
          ('stage3/exact_grid.py',['stage3/exact-grid.json']),
          ('stage3/exact_count_helper.py',['stage3/exact-count-helper.json']),
          ('stage5/exact_shortcut.py',['stage5/exact-shortcut-grid.csv']),
          ('stage6/exact_weighted_conversion.py',['stage6/exact-weighted-results.json']),
          ('stage5/analyze_followup.py',['stage5/followup-summary.csv']),
          ('stage7/analyze_sweep.py',['stage7/sweep-summary.csv','stage7/sweep-paired.csv'])]
    records=[]
    with tempfile.TemporaryDirectory(prefix='reservoir-replay-') as tmp:
        scratch=Path(tmp)/'evidence';shutil.copytree(source,scratch)
        for script,outputs in jobs:
            # Remove expected outputs first: stale copied files cannot count as success.
            for output in outputs:(scratch/output).unlink()
            proc=subprocess.run([sys.executable,str(scratch/script)],cwd=scratch,capture_output=True,text=True)
            checks=[]
            for output in outputs:
                generated=scratch/output
                check={'file':output,'generated':generated.exists(),
                    'byte_identical':generated.exists() and generated.read_bytes()==(source/output).read_bytes()}
                decimal=Path(output).name in ('followup-summary.csv','sweep-summary.csv','sweep-paired.csv')
                if decimal and generated.exists():check.update(compare_csv(source/output,generated))
                check['criterion']='decimal CSV numerical agreement' if decimal else 'exact output byte identity'
                check['passed']=check.get('numerically_agree',False) if decimal else check['byte_identical']
                checks.append(check)
            records.append({'script':script,'exit_code':proc.returncode,'outputs':checks,'stderr':proc.stderr})
    ok=all(r['exit_code']==0 and all(c['passed'] for c in r['outputs']) for r in records)
    args.report.parent.mkdir(parents=True,exist_ok=True)
    args.report.write_text(json.dumps({'scope':'selected Python analyses only; no native rerun or timings','success':ok,'records':records},indent=2)+'\n')
    print(json.dumps({'success':ok,'scripts':len(records),'checked_outputs':sum(len(x['outputs']) for x in records)}))
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
