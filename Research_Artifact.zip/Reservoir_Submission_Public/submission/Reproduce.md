# Reproducibility entry point

Run commands from the extracted repository root. Preserve the distributed evidence. Python analysis outputs are checked on a temporary copy by the runner below. No absolute path to the researcher's computer is required by that runner.

## Selected analysis replay

Use Python 3.9.6 for the recorded environment; compatibility with other versions is not asserted. Installing dependencies requires network access.

```sh
python3 -m venv .replay-venv
.replay-venv/bin/python -m pip install -r supporting-evidence/stage7/clean-python-requirements.txt
.replay-venv/bin/python submission/replay_selected.py --report replay-report.json
```

The runner executes seven scripts and checks eight regenerated files against supplied evidence: five exact outputs, the earlier estimator follow-up summary, and both new ratio-sweep summaries. Expected output files are deleted from the temporary copy before execution. Five exact-output files require byte identity in this runner. The three decimal summary CSVs require identical columns, unique and matching row identities, exact categorical values, and finite numeric values satisfying `abs(actual-reference) <= 1e-12 + 1e-9*abs(reference)`. For `p` and `p_holm`, the absolute tolerance is zero, so very small probabilities cannot be replaced by zero or materially changed unnoticed. Reordered rows are matched by identifiers. Byte identity is reported separately for every file. This is an explicit comparison policy, not a proof of numerical accuracy or cross-platform determinism. Figure rendering can vary by platform; plots are regenerated but not compared. A failed comparison is a diagnostic to inspect, not permission to replace the reference file.

These commands do not regenerate native samples, repeat timing experiments or establish historical-environment equality. Historical `replay_python.py`, `verify_replay.py`, and report builders retain workspace-specific paths; they are provenance records, not the current portable entry point.

## Native ratio experiment

Install Julia 1.12.1 separately using its official distribution. The saved environment is `supporting-evidence/stage3/Project.toml` and `Manifest.toml`. Run the following on a **separate copy of the package**, because shell redirection replaces output. The experiment is much more expensive than summary replay.

```sh
julia --startup-file=no --project=supporting-evidence/stage3 -e 'using Pkg; Pkg.instantiate()'
JULIA_NUM_THREADS=1 julia --startup-file=no --project=supporting-evidence/stage3 supporting-evidence/stage7/native_ratio_sweep.jl > supporting-evidence/stage7/ratio-sweep.csv
.replay-venv/bin/python supporting-evidence/stage7/analyze_sweep.py
```

The saved protocol defines 12 configurations, 5,000 fresh reservoirs each, independent query seeds and 60,000 iid controls. Expected total: 180,000 output records. Fresh reservoirs total 60,000; records are not 180,000 independent reservoirs.

The selected native dependency replay already performed is documented in `supporting-evidence/stage7/clean-environment-report.md` and `native-replay.json`. Its three CSVs matched on the same host. That check is distinct from the new portable Python runner. A complete clean-machine build of every historical stage has not been claimed.

## Evidence map

- Stage 2: independent C++ implementation, frozen before source inspection.
- Stage 3: pinned MIT-licensed upstream source, local repairs, exact and native counterexamples, Julia environment.
- Stage 4: raw native synthetic timings.
- Stage 5: source history, recurrence checks, estimator follow-up and timing sensitivity. Private correspondence is excluded from this public release.
- Stage 6: weighted conversion argument and exact checks; uncertainty additions.
- Stage 7: ratio sweep, reference verification, selected isolated-dependency replay.
- Stage 8: post-audit effect sizes, detection sensitivity and source-law/timing diagnostics.
- Stage 9: verified reference additions and citation mapping.

`SHA256SUMS` in the package root describes the current package. Historical stage manifests describe their original exports and must not be treated as current-root manifests. The author approved MIT for newly authored code; see LICENSE-CODE.txt. Original MIT notices and other third-party licenses are retained.

## Audit-response diagnostics

```sh
.replay-venv/bin/python supporting-evidence/stage8/analyze_revision.py
.replay-venv/bin/python submission/test_compare_outputs.py
```

Run the analysis command on a copy if preserving its supplied outputs. This computes effect sizes, noncentral-t sensitivity thresholds and source-law/timing diagnostics from existing data; it generates no new native samples. Nine comparator regression tests cover rounding, material changes, very small probability changes, missing/duplicate rows, identifiers, schema and non-finite values. The latest same-host replay still produced eight byte-identical outputs. Reports of execution by an external auditor are not independently verified execution records.
