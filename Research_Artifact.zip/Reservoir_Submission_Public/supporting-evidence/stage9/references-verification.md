# Version 10 reference changes

Checked 4 October 2026. Added three references for specific roles, not a target bibliography count. No raw data or test decisions changed.

- StreamSampling.jl paper: bibliographic fields confirmed through Crossref, DOI 10.21105/jcon.00202. Content inspected in arXiv:2603.21996v2, especially Sections 4–6 (sampling categories, package interfaces, benchmark scope). Publisher-page retrieval failed. No claim that the final published wording matches the preprint. This reference distinguishes the package from its comparison file; no package-release audit was performed.
- Kalibera and Jones: DOI 10.1145/2464157.2464160, ISMM 2013, pp. 63–74, verified through Crossref and Kent. Read the introduction and methodological discussion in the institutional author manuscript https://kar.kent.ac.uk/33611/45/p63-kaliber.pdf. The repository https://kar.kent.ac.uk/33611/ explicitly labels the version as correcting ISMM 2013. Used to delimit which variance levels this study did not estimate; not to claim adoption of the full method.
- Politis and Romano 1992: title, editors, publisher and pp. 263–270 verified on the author's institutional publication list https://mathweb.ucsd.edu/~politis/DPpublication.html and Romano's Stanford profile. No DOI asserted. The full chapter was not inspected in this revision and its text is not asserted identical to the 1991 technical report. Both references remain identified separately; the 1991 report is the existing methodological source.

Numbering follows first appearance in the revised main paper. citation-map-v9-to-v10.json preserves the old-to-new mapping (temporary IDs 13–15 identify the newly inserted references). Historical reports retain their original numbering.

The attached review's proposed deletion of TOSEM volume/issue and title comma was not adopted because current Crossref data supports the existing entry. No public publication or new communication occurred.
