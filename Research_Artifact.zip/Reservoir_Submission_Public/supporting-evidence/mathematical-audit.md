# Mathematical audit — preliminary, 2026-10-03

The following calculations concern the author manuscript arXiv:2403.20256v7, Section 3. They must not yet be attributed to an error in the publisher's version. No claim of priority is made.

Let $p_t=w_t/W_t$, $W_t=\sum_{i=1}^{t}w_i$, and $a_t=1-(1-p_t)^m$. For a binomial variable $B_t\sim\operatorname{Bin}(m,p_t)$,

$$\mathbb E[B_t\mid B_t>0]=\frac{mp_t}{a_t}.$$

The displayed expectation in the efficiency proof substitutes $mp_t$ for the mean of the positive-truncated binomial. Under the proof's abstract cost convention (one variate for a threshold, one for the conditional count, and one per replaced position), our calculation gives

$$\mathbb E[X]=1+\sum_{t=2}^{N}(2a_t+mp_t),$$

rather than $1+\sum_t a_t(2+mp_t)$. The latter undercounts by

$$\sum_{t=2}^{N}mp_t(1-a_t).$$

For $m=1$, $N=2$, $w_1=w_2=1$, an update occurs with probability $1/2$ and inserts exactly one item. This cost convention gives $1+3/2=2.5$, whereas the displayed expression gives $1+(1/2)(2+1/2)=2.25$. This counts conceptual draws, including a degenerate position choice; optimized implementations can use fewer primitive RNG calls.

The asymptotic bound survives the correction. Since $a_t\leq mp_t$,

$$\mathbb E[X]\leq 1+3m\sum_{t=2}^{N}p_t
\leq 1+3m\log\frac{W_N}{w_1}.$$

The additive constant is necessary at $N=1$. A claim about random-variate counts is not by itself a bound on elapsed processing time: reading $N$ arbitrary stream items costs $\Omega(N)$, and initializing the reservoir costs $\Omega(m)$. Under constant expected cost per count draw and $\mathcal O(k)$ uniform subset selection, an implementation can achieve expected time

$$\mathcal O\left(N+m+m\log\frac{W_N}{w_1}\right),$$

with $\mathcal O(m)$ auxiliary storage. The current Python pilot uses library subset selection whose exact cost is not asserted to meet this bound. A conservative $\mathcal O(Nm)$ bound applies to replacement/subset work across all items when the subset routine costs at most $\mathcal O(m)$ per event. Rejection repetitions in the positive-binomial helper have bounded expectation but no finite worst-case bound. Input storage is separate from auxiliary storage. Returning a reservoir reference is $\mathcal O(1)$; producing an independent copy is $\Theta(m)$.

Joint correctness can be established directly. For a particular subset $A$ of $k$ slots, drawing a binomial count followed by a uniform subset gives

$$\Pr(\text{replacement set}=A)=\frac{\binom{m}{k}p^k(1-p)^{m-k}}{\binom{m}{k}}=p^k(1-p)^{m-k}.$$

Thus the replacement indicators have exactly the joint law of independent Bernoulli draws. With fresh randomness independent of the current reservoir, induction preserves the product categorical distribution. A skip mechanism that preserves the first nonempty-update time and the conditional subset law preserves this process. Checking marginal frequencies alone would not test that joint property.

The correction is a small audit observation, not evidence of a faulty sampler, a new asymptotic result, or a sufficient standalone publication. The proposed contribution remains independent replication.

[1] A. Meligrana and A. Fazzone, “Weighted Reservoir Sampling With Replacement from Data Streams,” arXiv:2403.20256v7, Mar. 2026. https://arxiv.org/html/2403.20256v7
