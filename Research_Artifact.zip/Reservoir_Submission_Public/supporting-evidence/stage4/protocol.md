# Stage 4: native corrected performance study

Written before the stage-4 timing pilot, 2026-10-03. Earlier results remain archived.

## Objective

Measure the pinned Julia comparison implementation before and after the independently validated repairs. Match synthetic weight sequences, reservoir fractions, Julia version, Add units and exclusion of construction. Do not claim identity to the authors' hardware, unarchived dependency manifest, RNG trajectory or figure-generating commit. Source-informed reproduction follows the independent stage-2 phase.

## Design

Use original and corrected modules. The corrected module changes the shared count factor n-i to n-i+1; its exponential-key Get uses the validated distinct-rank conversion. Add kernels are otherwise identical. All samplers use integer item identifiers and Xoshiro with fixed seed per replicate. Original/repair versions and algorithms run in randomized order within each configuration/replicate. Warm each specialization before measurement. Generate weights and construct samplers outside Add timing; retain ordinary GC behaviour. Report total seconds and ns/item. Record GC time and allocations returned by Julia's @timed macro.

Candidate primary grid: N=1,000,000 and 10,000,000; m/N in {0.0001,0.001,0.01,0.1}; weights 1/i,1,i; BINARY/BIN, SKIP and EXPJ; original and repaired; 20 replicates. This is 1,440 records. A pilot at N=1,000,000,m=100,000 checks cost and exceptions before committing to the full grid. If the projected experiment exceeds 20 minutes, narrow N or replicates before the primary run, record the decision, and avoid calling reduced results a complete figure reproduction.

Get measurements use a noinline wrapper and an observable result checksum. BIN/SKIP return their stored reference, matching the interface in the pinned artifact; EXPJ builds its sample. Use 1,000 calls per timing batch for reference-return methods and max(1,min(20,10000/m)) for EXPJ. These measure harness-inclusive warm-cache per-call latency; the noinline wrapper and checksum dominate very small reference-return times. No inference about nanosecond differences between BIN/SKIP Get is planned. Their interface and asymptotic distinction are reported separately from materialized retrieval in stage 3. One batch is the observation; Get calls are not treated as independent replicates.

## Analysis

For Add, report means, SDs, t-based 95% confidence intervals. Pair original and repaired by configuration/algorithm/replicate and analyse log ratios, with Holm correction over 72 version contrasts. Analyse repaired SKIP/BIN and SKIP/EXPJ contrasts in a separate 48-contrast family. Use ratio <1 for lower time. All records, including unfavourable results and failures, are retained. These tests are descriptive evidence about this machine under this implementation, not universal rankings or proof of the original figures' correctness.

No real-data or hardware-generalization claim without an executed matching experiment. Writing follows measured results. Author-contact channel choice is pending; no public report is posted by default.

## Execution decision — 2026-10-04

The six-cell pilot completed without exceptions; Add times ranged from 0.0202 to 0.0484 seconds at the pilot configuration. These observations supported executing the entire candidate grid within the time allowance. No primary configurations or replicates were removed. Pilot measurements are excluded from primary inference. The machine remained available to its owner; absence of other background load cannot be established. No concurrent analysis or compilation task was deliberately run during primary timing.

### Arithmetic correction before analysis

The protocol initially misstated the record total as 1,440. The explicitly specified factorial grid produces $2\times3\times4\times3\times2\times20=2,880$ records. The executed design has not changed; the validation assertion is corrected to 2,880. The 72 version contrasts and 48 algorithm contrasts were correctly specified.
