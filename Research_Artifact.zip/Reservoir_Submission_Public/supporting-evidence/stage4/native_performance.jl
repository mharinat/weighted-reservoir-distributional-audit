using Random, Statistics
module Original
using Random, DataStructures, Distributions, WeightVectors, StatsBase
import Base:get
include(joinpath(@__DIR__,"..","stage3","upstream","samplers.jl"))
end
module Repaired
using Random, DataStructures, Distributions, WeightVectors, StatsBase
import Base:get
include(joinpath(@__DIR__,"..","stage3","upstream","samplers-count-fixed.jl"))
end
include("conversion_repair.jl")
const SINK=Ref{UInt}(0)
Base.@noinline function get_wrapped(s,f)
 v=f(s)
 SINK[]=SINK[]⊻UInt(v[1])
 return nothing
end
function add_kernel(s,w,f)
 @inbounds for i in eachindex(w);f(s,i,w[i]);end
 return nothing
end
function get_kernel(s,f,B)
 for _ in 1:B;get_wrapped(s,f);end
 return nothing
end
function construct(version,alg,m,seed)
 M=version=="original" ? Original : Repaired
 a=alg=="BIN" ? M.AlgWRSWRBIN() : alg=="SKIP" ? M.AlgWRSWRSKIP() : M.AlgWRAExpJ()
 s=M.ReservoirSampler{Int}(Xoshiro(seed),m,a)
 gf=version=="repaired" && alg=="EXPJ" ? get_distinct! : get
 return s,M.add!,gf
end
function one(version,alg,m,seed,w)
 s,af,gf=construct(version,alg,m,seed)
 A=@timed add_kernel(s,w,af)
 B=alg=="EXPJ" ? max(1,min(20,div(10000,m))) : 1000
 G=@timed get_kernel(s,gf,B)
 return A,G,B
end
function main()
 pilot=length(ARGS)>0 && ARGS[1]=="pilot"
 println("N,m,pattern,rep,seed,version,algorithm,add_seconds,add_gc_seconds,add_bytes,get_batch_seconds,get_calls,get_gc_seconds,get_bytes")
 order=Xoshiro(413008)
 ns=pilot ? [1000000] : [1000000,10000000]
 for N in ns
  for pattern in (pilot ? [2] : [0,1,2])
   w=pattern==0 ? [1.0/i for i in 1:N] : pattern==1 ? ones(N) : Float64.(1:N)
   ms=pilot ? [100000] : [div(N,10000),div(N,1000),div(N,100),div(N,10)]
   for m in ms
    jobs=[(v,a) for v in ["original","repaired"] for a in ["BIN","SKIP","EXPJ"]]
    for (v,a) in jobs;one(v,a,m,800,w);end
    for rep in 1:(pilot ? 1 : 20)
     for (v,a) in shuffle(order,jobs)
      A,G,B=one(v,a,m,71000+rep,w)
      println(join((N,m,pattern,rep,71000+rep,v,a,A.time,A.gctime,A.bytes,G.time,B,G.gctime,G.bytes),","))
      flush(stdout)
     end
    end
    println(stderr,"completed N=",N," pattern=",pattern," m=",m)
   end
  end
 end
end
main()
