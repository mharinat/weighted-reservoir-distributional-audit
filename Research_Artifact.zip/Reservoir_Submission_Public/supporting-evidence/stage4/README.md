# Native performance and manuscript, stage 4

This source-informed extension follows the frozen independent stage 2 and native correctness diagnostics in stage 3. Its interpretation is restricted to the pinned public comparison artifact. It is not an exact recreation of the historical published environment.

## Reproduce

Use Julia 1.12.1 with `../stage3/Project.toml` and its Manifest. Set `JULIA_NUM_THREADS=1`. A separate depot is recommended. Instantiate the project once before measurements. Python dependencies are NumPy 2.0.2, pandas 2.2.3, SciPy 1.13.1 and matplotlib 3.9.4.

From this directory, with Julia and Python available:

```sh
julia --startup-file=no --project=../stage3 -e 'using Pkg; Pkg.instantiate()'
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_performance.jl pilot > performance-pilot.csv
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_performance.jl > performance.csv
python analyze.py
```

Run in a new output copy if retaining the supplied measurements. The primary command overwrites its CSV. The Julia script loads original and repaired code from stage 3 using paths relative to its own file. It preserves upstream functions and dispatches the repaired converter separately. No external datasets or paid APIs are required. Weights are generated deterministically; all sampler and scheduling seeds are explicit in source.

## Files

- `protocol.md`: design recorded before execution, with dated arithmetic correction.
- `performance.csv`: all 2,880 primary records, including timings, allocation counts and GC times.
- `performance-pilot.csv`: six excluded pilot records.
- `performance-summary.csv`: means, sample SDs and marginal t-based 95% intervals; twenty observations per row.
- `repair-contrasts.csv`: paired Add repair/original log-ratio tests, Holm family of 72.
- `algorithm-contrasts.csv`: repaired SKIP/BIN and SKIP/EXPJ Add tests, Holm family of 48.
- `native-performance.png`, `.svg`: corrected processing results.
- `validation.json`: completeness and numerical checks plus descriptive counts.

Timing observations are repeated runs on one machine, not independent hardware samples. The statistical intervals are conditional on this run's measurement assumptions; they are not guarantees for a future machine. Original and repaired EXPJ Add code is algorithmically unchanged, providing a variability control. No equivalence conclusion follows from a non-significant comparison. Large-scale timing does not replace distributional validation.

Submission has not occurred. The author-verification report remains in `../stage3/author-verification-report.md` and is unsent. Public repository/DOI metadata, author details and a documented contact attempt remain outstanding.
