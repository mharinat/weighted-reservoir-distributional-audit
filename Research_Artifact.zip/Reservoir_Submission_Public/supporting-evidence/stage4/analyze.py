from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
D=pd.read_csv(P/'performance.csv')
keys=['N','m','pattern','version','algorithm']
assert len(D)==2880
assert not D.duplicated(keys+['rep']).any()
assert D.groupby(keys).size().eq(20).all()
assert (D[['add_seconds','get_batch_seconds']]>0).all().all()
assert np.isfinite(D.select_dtypes('number')).all().all()
D['add_ns_item']=D.add_seconds/D.N*1e9
D['get_ns_call']=D.get_batch_seconds/D.get_calls*1e9
rows=[]
for key,g in D.groupby(keys):
 r=dict(zip(keys,key))
 for metric in ['add_ns_item','get_ns_call']:
  a=g[metric].to_numpy();mean=a.mean();sd=a.std(ddof=1);h=stats.t.ppf(.975,len(a)-1)*sd/np.sqrt(len(a))
  r.update({metric+'_mean':mean,metric+'_sd':sd,metric+'_lo':mean-h,metric+'_hi':mean+h})
 r['replicates']=len(g);r['add_gc_seconds_total']=g.add_gc_seconds.sum();rows.append(r)
S=pd.DataFrame(rows);S.to_csv(P/'performance-summary.csv',index=False)
def contrast(a,b,meta):
 z=np.log(np.asarray(a)/np.asarray(b));mu=z.mean();sd=z.std(ddof=1);h=stats.t.ppf(.975,len(z)-1)*sd/np.sqrt(len(z))
 return dict(meta,ratio=np.exp(mu),lo=np.exp(mu-h),hi=np.exp(mu+h),p=stats.ttest_1samp(z,0).pvalue,log_sd=sd,n=len(z))
def holm(rs):
 ps=np.array([r['p'] for r in rs]);ix=np.argsort(ps);adj=np.minimum(1,np.maximum.accumulate(ps[ix]*(len(ps)-np.arange(len(ps)))))
 for j,v in zip(ix,adj):rs[j]['p_holm']=v;rs[j]['decision']='faster' if v<.05 and rs[j]['ratio']<1 else 'slower' if v<.05 else 'not_detected'
 return pd.DataFrame(rs)
rs=[]
for key,g in D.groupby(['N','m','pattern','algorithm']):
 t=g.pivot(index='rep',columns='version',values='add_seconds').sort_index()
 rs.append(contrast(t.repaired,t.original,dict(zip(['N','m','pattern','algorithm'],key))))
V=holm(rs);assert len(V)==72;V.to_csv(P/'repair-contrasts.csv',index=False)
rs=[]
for key,g in D[D.version=='repaired'].groupby(['N','m','pattern']):
 t=g.pivot(index='rep',columns='algorithm',values='add_seconds').sort_index()
 for base in ['BIN','EXPJ']:
  rs.append(contrast(t.SKIP,t[base],dict(zip(['N','m','pattern'],key),baseline=base)))
A=holm(rs);assert len(A)==48;A.to_csv(P/'algorithm-contrasts.csv',index=False)
fig,axs=plt.subplots(2,3,figsize=(11,6),sharex=True)
for row,N in enumerate(sorted(D.N.unique())):
 for col,pattern in enumerate([0,1,2]):
  ax=axs[row,col]
  for alg in ['BIN','SKIP','EXPJ']:
   g=S[(S.N==N)&(S.pattern==pattern)&(S.version=='repaired')&(S.algorithm==alg)].sort_values('m')
   ax.errorbar(g.m/N,g.add_ns_item_mean,yerr=[g.add_ns_item_mean-g.add_ns_item_lo,g.add_ns_item_hi-g.add_ns_item_mean],label=alg,marker='o',capsize=2)
  ax.set_xscale('log');ax.set_yscale('log');ax.grid(alpha=.2);ax.set_title(f'N={N:,}, '+['w(i)=1/i','w(i)=1','w(i)=i'][pattern])
  if row==1:ax.set_xlabel('Reservoir fraction m/N')
  if col==0:ax.set_ylabel('Add time (ns/item)')
axs[0,0].legend();fig.tight_layout();fig.savefig(P/'native-performance.png',dpi=180);fig.savefig(P/'native-performance.svg');plt.close(fig)
summary={'records':len(D),'configurations':24,'replicates':20,'version_contrasts':72,'algorithm_contrasts':48,'zero_durations':0,'add_gc_records':int((D.add_gc_seconds>0).sum()),'total_measured_add_seconds':float(D.add_seconds.sum()),'repair':{},'repaired_comparisons':{}}
for alg,g in V.groupby('algorithm'):summary['repair'][alg]={'decisions':g.decision.value_counts().to_dict(),'ratio_min':g.ratio.min(),'ratio_max':g.ratio.max()}
for alg,g in A.groupby('baseline'):summary['repaired_comparisons'][alg]={'decisions':g.decision.value_counts().to_dict(),'ratio_min':g.ratio.min(),'ratio_max':g.ratio.max()}
(P/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
