# Source-informed conversion repair, identical to the stage-3 validated function.
function get_distinct!(s)
    kvs = sort(s.value.valtree, by=x->x[2][1], rev=true)
    sampler=s.sampler
    for i in eachindex(sampler)
        sampler[i]=0.0
    end
    out=s.samplevalue
    out[1]=kvs[1][1]
    sampler[1]=kvs[1][2][2]
    used=1
    remaining=s.totalw-kvs[1][2][2]
    if s.n>1
        sampler[2]=remaining
    end
    for j in 2:s.n
        i=rand(s.rng,sampler)
        if i<=used
            out[j]=kvs[i][1]
        else
            @assert i==used+1
            used+=1
            out[j]=kvs[used][1]
            sampler[used]=kvs[used][2][2]
            remaining-=kvs[used][2][2]
            if used<s.n
                sampler[used+1]=remaining
            end
        end
    end
    return out
end

