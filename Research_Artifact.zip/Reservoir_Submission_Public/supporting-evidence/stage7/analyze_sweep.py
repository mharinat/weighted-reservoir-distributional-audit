from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;D=pd.read_csv(P/'ratio-sweep.csv');assert len(D)==180000
assert not D.duplicated(['N','m','pattern','rep','method']).any()
assert D.groupby(['N','m','pattern','method']).size().eq(5000).all()
assert np.isfinite(D.select_dtypes('number')).all().all()
def holm(p):
 p=np.asarray(p);ix=np.argsort(p);r=np.empty(len(p));r[ix]=np.minimum(1,np.maximum.accumulate(p[ix]*(len(p)-np.arange(len(p)))));return r
def mean_stats(x):
 x=np.asarray(x);n=len(x);mu=x.mean();sd=x.std(ddof=1);h=stats.t.ppf(.975,n-1)*sd/np.sqrt(n)
 return dict(mean=mu,sd=sd,lo=mu-h,hi=mu+h,p=stats.ttest_1samp(x,0).pvalue)
rows=[]
for key,g in D.groupby(['N','m','pattern','method']):
 err=g['mean']-g.population_mean;v=g.iid_mean_variance.iloc[0];r=dict(zip(['N','m','pattern','method'],key),**mean_stats(err));ms=mean_stats(g.squared_error/v)
 r.update(mse_ratio=ms['mean'],mse_lo=ms['lo'],mse_hi=ms['hi'])
 n=len(g);c=g.covered.mean();z=stats.norm.ppf(.975);den=1+z*z/n;center=(c+z*z/(2*n))/den;h=z*np.sqrt(c*(1-c)/n+z*z/(4*n*n))/den
 r.update(coverage=c,coverage_lo=center-h,coverage_hi=center+h);rows.append(r)
S=pd.DataFrame(rows);S['p_holm']=holm(S.p);S.to_csv(P/'sweep-summary.csv',index=False)
rows=[]
for key,g in D.groupby(['N','m','pattern']):
 t=g.pivot(index='rep',columns='method',values='mean');z=(t.original-t.corrected).to_numpy();r=dict(zip(['N','m','pattern'],key),**mean_stats(z));h=stats.t.ppf(1-.05/(2*12),len(z)-1)*r['sd']/np.sqrt(len(z));r.update(family_lo=r['mean']-h,family_hi=r['mean']+h);rows.append(r)
A=pd.DataFrame(rows);A['p_holm']=holm(A.p);A.to_csv(P/'sweep-paired.csv',index=False)
fig,axes=plt.subplots(1,3,figsize=(11,3.6),sharey=True)
for ax,pattern in zip(axes,['uniform','increasing','decreasing']):
 g=A[A.pattern==pattern].sort_values('m');ax.errorbar(g.m/g.N,g['mean'],yerr=[g['mean']-g.family_lo,g.family_hi-g['mean']],fmt='o',capsize=4,color='#1769aa');ax.axhline(0,color='gray',ls='--');ax.set_title(pattern+' weights');ax.set_xlabel('Reservoir fraction m/N');ax.grid(alpha=.2)
axes[0].set_ylabel('Original minus repaired mean');fig.tight_layout();fig.savefig(P/'bias-ratio-sweep.png',dpi=180);fig.savefig(P/'bias-ratio-sweep.svg');plt.close(fig)
validation={'records':len(D),'fresh_reservoirs':60000,'iid_control_outputs':60000,'configurations':12,'replicates_per_configuration':5000,'paired_rejections':A[A.p_holm<.05][['pattern','m']].to_dict('records'),'bias_rejections':S[S.p_holm<.05][['pattern','m','method']].to_dict('records'),'paired_family_size':12,'bias_family_size':36,'simultaneous_interval':'Bonferroni 12 two-sided t intervals; 95% family coverage under assumptions','not_claimed':'equivalence, universal monotonicity or cross-hardware timing'}
(P/'sweep-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(A[['pattern','m','mean','family_lo','family_hi','p_holm']].to_string(index=False));print('Bias rejections:',validation['bias_rejections'])
