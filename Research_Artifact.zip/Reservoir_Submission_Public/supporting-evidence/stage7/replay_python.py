from pathlib import Path
import shutil,subprocess,json,hashlib,sys
root=Path('outputs/Reservoir_Research_Current/supporting-evidence').resolve();copy=Path('work/reservoir-stage7/replay').resolve();shutil.copytree(root,copy,dirs_exist_ok=True)
python=Path('work/reservoir-stage7/clean-python/bin/python').absolute();records=[]
jobs=[('stage3/exact_audit.py','stage3/exact-audit.json'),('stage3/exact_grid.py','stage3/exact-grid.json'),('stage3/exact_count_helper.py','stage3/exact-count-helper.json'),('stage5/exact_shortcut.py','stage5/exact-shortcut-grid.csv'),('stage6/exact_weighted_conversion.py','stage6/exact-weighted-results.json'),('stage5/analyze_followup.py','stage5/followup-summary.csv')]
for script,out in jobs:
 proc=subprocess.run([str(python),str(copy/script)],capture_output=True,text=True)
 same=proc.returncode==0 and (copy/out).read_bytes()==(root/out).read_bytes()
 records.append(dict(script=script,exit_code=proc.returncode,output=out,byte_identical=same,stderr=proc.stderr))
 assert proc.returncode==0,(script,proc.stderr)
(copy/'python-replay.json').write_text(json.dumps(records,indent=2));(root/'stage7/python-replay.json').write_text(json.dumps(records,indent=2))
freeze=subprocess.check_output([str(python),'-m','pip','freeze'],text=True);(root/'stage7/clean-python-requirements.txt').write_text(freeze)
print(json.dumps(records,indent=2))
