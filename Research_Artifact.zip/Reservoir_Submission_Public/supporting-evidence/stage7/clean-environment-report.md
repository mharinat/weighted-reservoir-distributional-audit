# Isolated dependency replay

Date: 2026-10-04. Host: the same Apple M3/macOS machine as the recorded work. This is dependency isolation, not an independent hardware or investigator replication.

A new Python virtual environment was created without inherited site packages, then installed from the four pinned stage-2 requirements. The resolved transitive package versions are in `clean-python-requirements.txt`. A new Julia depot was instantiated from the existing Project/Manifest using the verified Julia 1.12.1 executable. The Julia runtime binary and OS are shared with earlier execution; compiled packages and dependency installation were fresh in the new depot. Download caches may have supplied Python wheels.

Six Python replays produced byte-identical selected outputs: the conversion counterexample, 18-case uniform grid, count-helper counterexample, 296-case count grid, 19-case weighted grid, and follow-up estimator summary. Three native Julia raw outputs also matched byte-for-byte: the million-sample-per-method occupancy test, the original nine-cell routine check, and its count-repaired counterpart. Records and SHA256 comparisons are in `python-replay.json` and `native-replay.json`. This checks the named outputs, not every generated file or all assumptions.

The first Python replay attempt incorrectly resolved the virtual-environment executable symlink to the base interpreter, causing `ModuleNotFoundError: pandas`. The launcher was corrected to use the absolute virtual-environment path without resolving that symlink. The successful rerun and environment record correspond to the corrected invocation. This was a replay-launcher error, not a defect detected in the scientific data.

The native replays cover 3,000,000 occupancy outputs plus 1,800,000 original and 1,800,000 repaired routine-check outputs. The occupancy experiment reuses a fixed reservoir for its invariant statistic; these are not all independently rebuilt reservoirs. Performance and the entire historical analysis pipeline were not rerun. The new ratio sweep ran separately in the prior validated Julia environment, not in the isolated-depot replay.

No claim of a complete clean build or cross-platform validation is made. The archived original manifests and raw observations are unchanged.
