from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;root=P.parent;work=Path('work/reservoir-stage7').resolve();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for replay,ref in [('replayed-native-counts.csv','native-counts.csv'),('replayed-native-targets.csv','native-targets.csv'),('replayed-native-targets-fixed.csv','native-targets-fixed.csv')]:
 a=work/replay;b=root/'stage3'/ref;same=a.read_bytes()==b.read_bytes();rows.append({'file':ref,'same_sha256':same,'replay_sha256':h(a),'reference_sha256':h(b)});assert same,ref
for name in ['python-install.log','julia-install.log','native-replay.log','targets-replay.log','targets-fixed-replay.log','sweep.log']:
 shutil.copy2(work/name,P/name)
P.joinpath('native-replay.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
