# Stage 7: references, isolated-environment replay, and a fixed ratio sweep

Saved before the new sweep, 2026-10-04. This extension was motivated by the prior positive result; it is not an unselected validation of all weighted sampling applications.

## Ratio sweep

Fix N=10000 and m in {100,500,1000,2000}, giving reservoir fractions {0.01,0.05,0.1,0.2}. Use uniform weights, increasing weights w_i=i, and decreasing weights w_i=N+1-i. Each of the twelve configurations uses 5000 fresh EXPJ reservoirs. Each reservoir yields one original and one repaired conversion with separately reseeded query RNGs. An iid categorical control is drawn separately. All normalized-label means, squared errors, nominal coverage and collision counts are retained. There are 180000 output records on 60000 reservoirs plus 60000 iid controls. Sampler RNG seeds are 10000000+case_id*1000000+10*rep; query offsets are 1,2,3. Configurations have disjoint seed ranges.

Primary estimand: paired original-minus-repaired normalized-label mean. Report two-sided paired t tests with Holm correction over 12 contrasts, SD, marginal t-based 95% CI and a 99.5833% Bonferroni interval per contrast (simultaneous familywise coverage under the t assumptions). Report separate bias-to-reference tests for all 36 method/configuration cells, Holm-adjusted within that family. No equivalence claim follows from non-rejection. MSE ratios and coverage are secondary descriptive quantities with marginal intervals. The decreasing-weight case probes sign reversal; uniform weights are a control. No assertion of monotonic growth will be made without observing the grid, and no unsampled regimes will be inferred. Earlier and new results are not pooled. All 5000 observations are kept; no interim significance-based stopping.

## Isolated dependency replay

Create a fresh Python virtual environment and a new Julia depot; instantiate the saved Julia 1.12.1 manifest. Use the existing verified Julia runtime on the same machine. Package downloads may use caches; no previously installed package environment is inherited. Replay exact enumeration and selected native raw-output experiments in a separate copy of the research tree. Compare against saved hashes, record mismatches and process exit codes. This is a same-host dependency isolation check, not an independent-machine replication or a rerun of the entire performance campaign.

## Literature

Verify methodological citations for Holm adjustment, Wilson intervals, circular block bootstrap and recent sampler testing. Distinguish statistical testing, machine-checked verification and source-informed exact counterexamples. Do not claim an exhaustive novelty search, Q-ranking or peer review for an arXiv-only record. Add references only where the manuscript uses their content. Keep publisher access failures explicit.
