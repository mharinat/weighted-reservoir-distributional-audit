from pathlib import Path
from urllib.request import urlopen,Request
import json
p=Path('outputs/Reservoir_Research_Current/supporting-evidence/stage7');d={}
for doi in ['10.2307/4615733','10.1080/01621459.1927.10502953','10.1145/3797477','10.1145/3591220','10.1609/aaai.v38i8.28632']:
 try:
  with urlopen(Request('https://api.crossref.org/works/'+doi,headers={'User-Agent':'Research-citation-verification'}),timeout=30) as f:m=json.load(f)['message']
  d[doi]={k:m.get(k) for k in ['DOI','title','author','container-title','volume','issue','page','article-number','published','URL','link']}
 except Exception as e:d[doi]={'error':str(e)}
(p/'citation-metadata.json').write_text(json.dumps(d,indent=2));print(json.dumps(d,indent=2))
