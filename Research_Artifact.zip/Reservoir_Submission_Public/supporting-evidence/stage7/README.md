# Stage 7 extension

The current paper remains `../../Research_Manuscript.md`. This directory adds selected references, isolated-dependency replay evidence, and the twelve-configuration ratio experiment. No historical data are overwritten.

## Reproduce the new experiment

With Julia 1.12.1 and the dependencies in `../stage3/Project.toml` instantiated:

```sh
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_ratio_sweep.jl > ratio-sweep.csv
python analyze_sweep.py
```

Use a copied artifact to preserve supplied output. Python versions are pinned in `clean-python-requirements.txt`; installing that file into a new venv reconstructs the resolved Python package environment used for the replay. The Julia Manifest remains in stage3. Seeds, grid, statistical families and limits are specified in `protocol.md`; its local pre-execution hash is in `pre-execution.json`.

## Evidence

- `ratio-sweep.csv`: 180,000 output records, 60,000 fresh reservoirs plus 60,000 iid controls.
- `sweep-summary.csv`: 36 method/configuration estimates, SDs, intervals and Holm bias tests.
- `sweep-paired.csv`: 12 primary paired contrasts with marginal and Bonferroni-family intervals.
- `bias-ratio-sweep.png`, `.svg`: all paired contrasts, including undetected ones.
- `references-verification.md`, `citation-metadata.json`: roles, verified identifiers and retrieval limits.
- `clean-environment-report.md`: what was replayed and what was not.
- `python-replay.json`, `native-replay.json`: selected output equality checks; installer/execution logs are retained.

For a new isolated replay, create a fresh Python venv and Julia depot, install the saved requirements and Julia manifest, copy stages 3–6 to a scratch location, and execute the scripts named in `python-replay.json`. Execute `stage3/native_audit.jl` and `stage3/native_targets.jl` there, repeating the latter with `RESERVOIR_SOURCE_FILE` set to the absolute `stage3/upstream/samplers-count-fixed.jl` path. Compare to the corresponding saved CSV hashes. Do not resolve a venv interpreter symlink to the base executable. `verify_replay.py` records this session's workspace-specific log locations and is not a portable installer.
