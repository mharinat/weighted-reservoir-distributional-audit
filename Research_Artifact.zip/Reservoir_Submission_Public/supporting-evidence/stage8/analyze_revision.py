"""Post-audit descriptive diagnostics; no new samples or confirmatory test family."""
from pathlib import Path
import importlib.util,json
import numpy as np,pandas as pd
from scipy import stats,optimize
P=Path(__file__).resolve().parent;R=P.parent
D=pd.read_csv(R/'stage7/ratio-sweep.csv');n=5000;alpha=.05/12
critical=stats.t.ppf(1-alpha/2,n-1)
def power(lam):return stats.nct.sf(critical,n-1,lam)+stats.nct.cdf(-critical,n-1,lam)
lam80=optimize.brentq(lambda x:power(x)-.8,0,20)
rows=[]
for (pattern,m),g in D.groupby(['pattern','m']):
 t=g.pivot(index='rep',columns='method',values='mean');d=t.original-t.corrected
 assert len(d)==n
 sd=d.std(ddof=1)
 rows.append(dict(pattern=pattern,m=m,N=10000,n=n,mean=d.mean(),sd=sd,d_z=d.mean()/sd,t_stat=d.mean()/sd*np.sqrt(n),mde80=lam80*sd/np.sqrt(n),skew=stats.skew(d,bias=False),excess_kurtosis=stats.kurtosis(d,bias=False),correlation=t.original.corr(t.corrected)))
A=pd.DataFrame(rows);A.to_csv(P/'effect-sensitivity.csv',index=False)
spec=importlib.util.spec_from_file_location('grid',R/'stage3/exact_grid.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
g=pd.read_csv(R/'stage3/native-equal40.csv').query("method == 'original'");law=mod.source_law(40,4)
e=np.array([float(law[tuple(int(x) for x in v.split('-') if int(x))])*1000000 for v in g.partition]);chi=stats.chisquare(g['count'],e)
t=pd.read_csv(R/'stage4/performance.csv');v=t.groupby(['version','algorithm','N','m','pattern']).add_seconds.agg(['min','max']);v['max_min']=v['max']/v['min'];v[v.max_min>2.5].to_csv(P/'timing-variable-cells.csv')
wide=t.pivot(index=['version','N','m','pattern','rep'],columns='algorithm',values='add_seconds');ratios={}
for version,g in wide.groupby(level='version'):ratios[version]={'pairs':len(g)*2,'at_least_one':int(sum((g.SKIP/g[a]>=1).sum() for a in ['BIN','EXPJ']))}
(P/'diagnostics.json').write_text(json.dumps({'scope':'post-audit diagnostics using existing raw data','new_sampling':False,'N40_source_law':{'chi_square':float(chi.statistic),'df':4,'p_unadjusted':float(chi.pvalue)},'mde':{'alpha':alpha,'target_power':.8,'method':'noncentral t with observed SD; sensitivity, not prospective power','noncentrality':lam80},'timing_raw_ratios':ratios},indent=2)+'\n')
print('12 effect/sensitivity rows and diagnostic checks saved')
