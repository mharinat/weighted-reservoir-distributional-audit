# Statistical audit response — manuscript version 9

`analyze_revision.py` reads existing stage-3, stage-4 and stage-7 raw data and writes paired standardized effects, descriptive shape diagnostics, modeled 80% detection thresholds and timing/source-law diagnostics. Run with the pinned Python environment from any working directory. There are no new reservoir samples or timing experiments.

MDE uses observed SD, a fixed Bonferroni threshold and noncentral-t assumptions. It is post-audit detection sensitivity, not prospective power or an equivalence margin. The selected N=40 source-law test is unadjusted and descriptive. Original CSVs are unchanged.

The attached review and our assessment remain in `../../audit-review/`. The original report is preserved verbatim, including recommendations we do not adopt. The implemented response is in `../../audit-review/Revision_Response_AR.md`.
