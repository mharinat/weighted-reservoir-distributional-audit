from pathlib import Path
import json,math,hashlib
from fractions import Fraction
import numpy as np,pandas as pd
from scipy.stats import chisquare,t,ttest_1samp,norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent

def holm(rows):
 prev=0
 for j,x in enumerate(sorted(rows,key=lambda x:x['p'])):prev=max(prev,min(1,(len(rows)-j)*x['p']));x['p_holm']=prev

def wilson(k,n):
 z=norm.ppf(.975);p=k/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return [mid-half,mid+half]
def partition_probability(parts,N):
 parts=[x for x in parts if x];k=len(parts);num=math.factorial(sum(parts))*math.prod(N-i for i in range(k));den=N**sum(parts)*math.prod(math.factorial(x) for x in parts)
 for c in set(parts):den*=math.factorial(parts.count(c))
 return num/den

def occupancy(file,N):
 rows=[]
 for method,g in pd.read_csv(P/file).groupby('method',sort=False):
  n=int(g.repetitions.iloc[0]);probs=np.array([partition_probability(list(map(int,x.split('-'))),N) for x in g.partition]);stat,p=chisquare(g['count'],n*probs)
  k=int(g[g.partition=='2-2-0-0']['count'].iloc[0]);row=dict(method=method,N=N,n=n,chi2=float(stat),p=float(p),event_22=k/n,event_22_ci95=wilson(k,n),expected_min=float(min(n*probs)))
  if N==4 and method=='original':
   q=np.array([1/64,3/16,10/64,35/64,3/32]);row['p_vs_exact_source_law']=float(chisquare(g['count'],n*q).pvalue)
  rows.append(row)
 return rows

def multinomial(file,targets=False):
 d=pd.read_csv(P/file);rows=[]
 group=['case','method'] if targets else ['method']
 for key,g in d.groupby(group,sort=False):
  case,method=key if targets else ('weighted4',key[0] if isinstance(key,tuple) else key)
  probs=[.1,.2,.3,.4] if case=='weighted4' else [.25]*4;n=int(g.repetitions.iloc[0]);expected=[]
  for code in g['counts']:
   v=list(map(int,code.split('-')));expected.append(n*math.factorial(4)*math.prod(probs[i]**v[i]/math.factorial(v[i]) for i in range(4)))
  stat,p=chisquare(g.frequency,expected);rows.append(dict(case=case,method=method,n=n,chi2=float(stat),p=float(p),expected_min=float(min(expected))))
 return rows

def main():
 initial=occupancy('native-counts.csv',4);holm(initial)
 follow=occupancy('native-equal40.csv',40)+multinomial('native-weighted.csv');holm(follow)
 targets=multinomial('native-targets.csv',True);holm(targets)
 repaired=multinomial('native-targets-fixed.csv',True);holm(repaired)
 collisions=[];d=pd.read_csv(P/'native-collisions.csv')
 for method,g in d.groupby('method',sort=False):
  a=g.collisions.to_numpy();mean=float(a.mean());sd=float(a.std(ddof=1));half=float(t.ppf(.975,len(a)-1)*sd/math.sqrt(len(a)))
  collisions.append(dict(method=method,n=len(a),mean=mean,sd=sd,ci95=[mean-half,mean+half],expected_mean=49.95,expected_variance=49.95*.9999,p=float(ttest_1samp(a,49.95).pvalue)))
 holm(collisions)
 batches=pd.DataFrame([json.loads(x) for x in (P/'retrieval-batches.jsonl').read_text().splitlines()]);assert len(batches)==720 and (batches.batch_seconds>0).all();assert not batches.duplicated(['pattern','m','rep','algorithm']).any()
 summary=[]
 for keys,g in batches.groupby(['pattern','m','algorithm']):
  a=g.per_call_seconds.to_numpy();mean=float(a.mean());sd=float(a.std(ddof=1));half=float(t.ppf(.975,len(a)-1)*sd/math.sqrt(len(a)))
  summary.append(dict(pattern=int(keys[0]),m=int(keys[1]),algorithm=keys[2],batches=len(a),mean_seconds=mean,sd_seconds=sd,ci_low=mean-half,ci_high=mean+half))
 pd.DataFrame(summary).to_csv(P/'retrieval-summary.csv',index=False)
 result=dict(initial_native=initial,followup_native=follow,target_original=targets,target_count_fixed=repaired,collisions=collisions,retrieval_batches=len(batches),retrieval_calls=int(batches.calls.sum()),retrieval_min_batch_seconds=float(batches.batch_seconds.min()),native_generated_samples=3000000+3000000+300000+30000+1800000+1800000)
 (P/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False))
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 fig,ax=plt.subplots(figsize=(8,4.5));labels=['Original source','Conversion repair','IID control'];values=[x['event_22'] for x in initial];errs=np.array([[x['event_22']-x['event_22_ci95'][0],x['event_22_ci95'][1]-x['event_22']] for x in initial]).T
 ax.bar(labels,np.array(values)*100,color=['#c44e52','#2a9d8f','#486581']);ax.errorbar(range(3),np.array(values)*100,yerr=errs*100,fmt='none',ecolor='black',capsize=5)
 ax.axhline(100*9/64,color='black',linestyle='--',label='IID expectation: 14.0625%');ax.set_ylabel('Two pairs: probability (%)');ax.set_title('Unmodified Julia comparison code: N = m = 4, unit weights');ax.set_ylim(0,18);ax.legend();fig.tight_layout();fig.savefig(P/'native-counterexample.png',dpi=180);plt.close(fig)
 fig,axes=plt.subplots(1,3,figsize=(12,3.8));s=pd.DataFrame(summary)
 for pattern,ax in enumerate(axes):
  for alg,color in [('BIN','#486581'),('SKIP','#c44e52'),('EXPJ-CDF','#2a9d8f')]:
   g=s[(s.pattern==pattern)&(s.algorithm==alg)].sort_values('m');ax.errorbar(g.m,g.mean_seconds*1e6,yerr=(g.ci_high-g.mean_seconds)*1e6,label=alg,color=color,marker='o',capsize=3)
  ax.set_xscale('log');ax.set_yscale('log');ax.set_title(['Decreasing','Constant','Increasing'][pattern]);ax.set_xlabel('Reservoir size');ax.set_ylabel('Microseconds per materialized Get')
 axes[0].legend();fig.suptitle('Batched retrieval: 100 calls per batch, 20 reservoirs per configuration');fig.tight_layout();fig.savefig(P/'batched-retrieval.png',dpi=180);plt.close(fig)
 print(json.dumps({'initial':initial,'followup':follow,'source_rejections':[x for x in targets if x['p_holm']<.05],'fixed_rejections':[x for x in repaired if x['p_holm']<.05],'collisions':collisions,'retrieval_min_batch_seconds':result['retrieval_min_batch_seconds'],'native_generated_samples':result['native_generated_samples']},indent=2))
if __name__=='__main__':main()
