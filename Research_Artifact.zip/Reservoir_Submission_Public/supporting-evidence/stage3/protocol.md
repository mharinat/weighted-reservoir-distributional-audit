# Stage 3: source reconciliation and measurement repair

Date: 2026-10-03. Stage 2 is frozen; retain its independent implementation, results and hashes. This stage is explicitly source-informed, following inspection of the authors' code. Do not claim the same code-blind independence for new diagnostics.

## Source reconciliation

Pinned repository commit: 408dd06f8ea9e60b412e27a73f0f277bb590cb84, selected as the latest comparison-directory commit on or before 12 April 2026. It is not proven to be the precise version used to generate the published figures. The most recent change returned for samplers.jl itself is 686fa7aba586bbd02a7d9b1173eed245bf12f089 (17 November 2025).

The inspected code initializes SKIP from the first m stream items. Its Add benchmark excludes construction and reports nanoseconds per input item. BIN/SKIP Get returns a reference. The comparison Get sorts its heap and uses a dynamic sampler. These differences must be recorded before interpreting earlier performance reversals.

An exact post-inspection diagnostic for N=m=4 and unit weights found a discrepancy in a transcription of the comparison conversion. It enumerated 64 equally likely conversion paths against 256 iid sample paths, comparing occupancy partitions (hence invariant to sample ordering). Native confirmation is the next step; do not yet describe the transcription result as a confirmed runtime defect in the original code.

Native validation plan: Julia 1.12.1 from the official distribution, verified archive SHA256; run the unmodified pinned sampler code with documented dependencies. Test one million Get calls on a four-item, unit-weight reservoir. Occupancy partitions are invariant to retained key order, so reuse of this fixed reservoir is valid for this specific test. Compare to the iid law and the exact source-conversion law. Report Pearson p-values and a Wilson 95% CI for the (2,2) event. One fixed seed; no optional stopping. Retain failures and dependency versions. Do not claim general independence of repeated Get calls conditional on a fixed reservoir.

## Retrieval repair

Reuse frozen stage-2 implementation without modifying its algorithms. Time batches of 100 materialized Get operations at N=100,000, m in {10,100,1000,10000}, three weight patterns, three algorithms and 20 independently constructed reservoirs per cell. Total 720 batches. Randomize algorithm order within each replicate. Include destruction of the temporary returned vector and a minimal observable checksum in each timed batch; exclude Add. Record batch time and per-call time. Assert positive measured batch durations. Inferential unit is a batch on an independently initialized reservoir, not each of the 100 calls. This warm-cache throughput measurement is not the original paper's borrowed-reference metric.

No full native performance rerun is warranted until the comparison's sample-law discrepancy is resolved. Public communication, upstream issue filing, and journal submission are not authorized and will not be performed in this stage.

## Post-confirmation diagnostic extension

The original Julia code reproduced the four-item discrepancy. Add, with fixed seeds and without optional stopping: (a) N=40,m=4, equal weights, one million calls per original/corrected/iid method, occupancy tests; (b) N=m=4, weights (1,2,3,4), 100,000 independently constructed reservoirs per method, 35 full count-vector categories, all expected counts >=10; (c) N=10,000,m=1000, equal weights, 10,000 samples per method, raw collision-pair counts C. For iid uniform samples, E[C]=m(m-1)/(2N), Var(C)=choose(m,2)*(1/N)*(1-1/N). Occupancy/collision laws for equal weights are invariant to reservoir key order, so repeated queries to a fixed reservoir are valid for those diagnostics only. Report nominal tests with an explicitly separate Holm family for the six extension goodness-of-fit tests and a separate family for collision mean tests. These extensions were selected after the initial discrepancy; they are diagnostic follow-up, not preregistered confirmatory generalization.

## Additional source-code correctness screen

Inspection also found a count-generation shortcut in the comparison helpers that warrants testing. Before interpreting native source performance, add a separate nine-test family: original BERN/BIN/SKIP, three stream cases (unit weights N=8; unit weights N=40; N=4 with weights 1,2,3,4), m=4, 200,000 independently constructed reservoirs per cell. Aggregate labels modulo four for the longer unit-weight streams. Compare all 35 count vectors to the exact multinomial law; all expected counts exceed five. Apply Holm within this diagnostic family. This targets the pinned comparison code, not the current released StreamSampling package.

## Count-helper repair validation

The nine-test source screen rejected BIN on unit8 and weighted4 and SKIP on unit8 (before multiplicity adjustment); the other six cells did not reject. The shared macro multiplies the recurrence at step i by n-i, where the binomial recurrence requires n-i+1. Create a separately named local copy with exactly this one factor corrected; leave the source conversion unchanged. Rerun the same nine-cell screen with identical fixed seeds, labelled count-helper repair validation, and apply Holm to that new nine-test family. This is an intervention on the suspected cause, not an untouched independent replication. The upstream original remains byte-identical. No upstream repository is modified.
