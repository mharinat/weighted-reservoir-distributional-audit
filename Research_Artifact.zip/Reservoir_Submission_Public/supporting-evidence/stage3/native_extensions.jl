include(joinpath(@__DIR__,"native_audit.jl"))
function equal_extension()
 println("method,partition,count,repetitions")
 for (method,seed) in [("original",1201),("corrected",1202),("iid",1203)]
  rng=Xoshiro(seed);s=ReservoirSampler{Int}(rng,4,AlgWRAExpJ())
  for i in 1:40;add!(s,i,1.0);end
  counts=zeros(Int,5)
  for r in 1:1_000_000
   x=method=="original" ? get(s) : method=="corrected" ? get_distinct!(s) : rand(rng,1:40,4)
   d=Dict{Int,Int}();for v in x;d[v]=get(d,v,0)+1;end
   parts=sort(collect(values(d)),rev=true);append!(parts,zeros(Int,4-length(parts)))
   counts[findfirst(==(Tuple(parts)),PARTITIONS)]+=1
  end
  for k in 1:5;println(method,",",join(PARTITIONS[k],"-"),",",counts[k],",1000000");end
 end
end
function weighted_extension()
 println("method,counts,frequency,repetitions")
 keys=[(a,b,c,d) for a in 0:4 for b in 0:4 for c in 0:4 for d in 0:4 if a+b+c+d==4]
 for (method,seed) in [("original",1301),("corrected",1302),("iid",1303)]
  rng=Xoshiro(seed);freq=Dict(k=>0 for k in keys)
  for r in 1:100_000
   if method=="iid"
    x=[searchsortedfirst([1,3,6,10],rand(rng,1:10)) for _ in 1:4]
   else
    s=ReservoirSampler{Int}(rng,4,AlgWRAExpJ());for i in 1:4;add!(s,i,Float64(i));end
    x=method=="original" ? get(s) : get_distinct!(s)
   end
   k=Tuple(count(==(i),x) for i in 1:4);freq[k]+=1
  end
  for k in keys;println(method,",",join(k,"-"),",",freq[k],",100000");end
 end
end
function collision_extension()
 println("method,rep,collisions")
 for (method,seed) in [("original",1401),("corrected",1402),("iid",1403)]
  rng=Xoshiro(seed);s=ReservoirSampler{Int}(rng,1000,AlgWRAExpJ())
  for i in 1:10000;add!(s,i,1.0);end
  for r in 1:10000
   x=method=="original" ? get(s) : method=="corrected" ? get_distinct!(s) : rand(rng,1:10000,1000)
   d=Dict{Int,Int}();pairs=0
   for v in x;c=get(d,v,0);pairs+=c;d[v]=c+1;end
   println(method,",",r,",",pairs)
  end
 end
end
if ARGS[1]=="equal";equal_extension()
elseif ARGS[1]=="weighted";weighted_extension()
elseif ARGS[1]=="collisions";collision_extension()
else;error("unknown task")
end
