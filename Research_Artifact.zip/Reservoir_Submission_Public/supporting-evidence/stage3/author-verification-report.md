# Technical verification report — prepared locally, not sent

## Scope

We are independently studying the comparison artifact associated with *Weighted Reservoir Sampling with Replacement from Data Streams*, DOI 10.1145/3774904.3792966. We inspected `comparison/samplers.jl` at commit `408dd06f8ea9e60b412e27a73f0f277bb590cb84`. We have not established that this commit and our resolved dependencies are identical to those used for the article's figures. The observations below concern this file, not the complete current package or the mathematical validity of the sampling constructions.

## 1. Conversion of the exponential-key reservoir

For four unit-weight items and a sample of four, the count-partition probabilities required by iid uniform sampling are:

| Partition | Required | Exact path enumeration of conversion |
|---|---:|---:|
| 4 | 1/64 | 1/64 |
| 3+1 | 3/16 | 3/16 |
| 2+2 | 9/64 | 10/64 |
| 2+1+1 | 36/64 | 35/64 |
| 1+1+1+1 | 3/32 | 3/32 |

The suspected cause is an inconsistency between the output-position-based activation of sampler weights and the next-unseen-item pointer. A rank can be emitted through an already activated category without advancing the pointer. Tracking actually emitted distinct ranks avoids the discrepancy.

The unmodified Julia function produced 156,210 two-pair events in 1,000,000 samples. The locally repaired conversion produced 140,519; an iid control produced 140,572. The required expected count is 140,625. The original counts fit the enumerated conversion law (Pearson p=0.1592) and reject the iid law (p<1e-300). The equal-weight occupancy statistic is invariant to retained key order; no output-order independence assumption is used.

Additional checks at N=40,m=4, at unequal weights (1,2,3,4), and collision counts at N=10,000,m=1,000 are supplied in the artifact. The fixed-reservoir repeated-query design is used only for equal-weight, label-invariant statistics. The unequal-weight test constructs fresh reservoirs.

## 2. Shared binomial shortcut

At iteration i, the fast recurrence uses a factor `n-i`. The binomial recurrence requires `n-i+1`. Exact evaluation of the implemented branch intervals at n=4,p=1/4 gives:

- Probability of two replacements: 25/128 instead of 27/128.
- Probability of three replacements: 1/16 instead of 3/64.

The shared positive-truncated helper inherits the discrepancy. A one-factor local edit is supplied as `count-factor.patch`. The original BERN/BIN/SKIP diagnostic suite rejects BIN for an eight-item uniform stream and a four-item weighted stream, and SKIP for an eight-item uniform stream. No cell rejects after the one-factor repair, with Holm correction within each nine-cell family. This is not a claim that every input fails or that this edit addresses all floating-point boundaries.

## Reproduction

`README.md` gives the exact commands. The artifact includes unchanged upstream source and its MIT license, Julia 1.12.1 runtime provenance, Project.toml, Manifest.toml, exact enumerators, native tests and raw counts. Julia package versions: DataStructures 0.19.6, Distributions 0.25.131, StatsBase 0.34.13, WeightVectors 0.1.1. Our independent C++ implementation was frozen before this source inspection.

## Clarifications requested before interpreting the published results

1. Was this comparison-file version used for the reported figures? If not, which commit or archived artifact was used?
2. Are the reported conversion and count-helper behaviours already documented or corrected elsewhere?
3. Is there a different intended interpretation of the sample-count law that would change these tests?
4. Which dependency manifest and precise timing boundaries should be used for a matched, corrected comparison?

No public issue, claim of priority, or journal submission has been made. We would incorporate corrections to our interpretation and record the verification outcome before drawing conclusions about the published figures.
