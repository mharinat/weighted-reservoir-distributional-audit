include(joinpath(@__DIR__,"native_audit.jl"))
function targetchecks()
 println("case,method,counts,frequency,repetitions")
 keys=[(a,b,c,d) for a in 0:4 for b in 0:4 for c in 0:4 for d in 0:4 if a+b+c+d==4]
 for case in ["unit8","unit40","weighted4"]
  N=case=="unit8" ? 8 : case=="unit40" ? 40 : 4
  for (method,alg,seed) in [("BERN",AlgWRSWR(),1501),("BIN",AlgWRSWRBIN(),1502),("SKIP",AlgWRSWRSKIP(),1503)]
   rng=Xoshiro(seed);freq=Dict(k=>0 for k in keys)
   for rep in 1:200_000
    s=ReservoirSampler{Int}(rng,4,alg)
    for i in 1:N;add!(s,mod1(i,4),case=="weighted4" ? Float64(i) : 1.0);end
    x=get(s);k=Tuple(count(==(i),x) for i in 1:4);freq[k]+=1
   end
   for k in keys;println(case,",",method,",",join(k,"-"),",",freq[k],",200000");end
  end
 end
end
targetchecks()
