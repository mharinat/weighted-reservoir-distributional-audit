"""Source-informed diagnostic. Exact enumeration; no random simulations.
Pinned comparison/samplers.jl get(AlgWRAExpJSampler), commit
408dd06f8ea9e60b412e27a73f0f277bb590cb84. Positive equal weights, N=m=4.
The sorted key order is a random permutation. Occupancy partitions are invariant
under it, so we can fix ordered labels to [0,1,2,3].
"""
from fractions import Fraction
from itertools import product
from collections import Counter,defaultdict
from pathlib import Path
import json
P=Path(__file__).resolve().parent

def partition(xs):return tuple(sorted(Counter(xs).values(),reverse=True))
def published_conversion(units):
 out=[0];next_new=1
 for j,u in enumerate(units,start=1):
  # At Julia output index j+1: first j categories have weight 1;
  # category j+1 has remaining weight 4-j. u is uniform in 0..3.
  i=u if u<j else j
  if i<j:out.append(i)
  else:out.append(next_new);next_new+=1
 return out

def corrected_conversion(units):
 out=[0];used=1
 for u in units:
  if u<used:out.append(u)
  else:out.append(used);used+=1
 return out

def distribution(fn):
 d=defaultdict(Fraction)
 for u in product(range(4),repeat=3):d[partition(fn(u))]+=Fraction(1,64)
 return dict(d)

def main():
 reference=defaultdict(Fraction)
 for xs in product(range(4),repeat=4):reference[partition(xs)]+=Fraction(1,256)
 source=distribution(published_conversion);corrected=distribution(corrected_conversion)
 assert corrected==dict(reference)
 rows=[]
 for k in sorted(reference,reverse=True):
  rows.append({'partition':list(k),'iid':str(reference[k]),'source_conversion':str(source[k]),'corrected_conversion':str(corrected[k]),'difference':str(source[k]-reference[k])})
 tv=sum(abs(source[k]-reference[k]) for k in reference)/2
 result={'case':'N=m=4; all weights 1; occupancy partition, independent of key order','source_commit':'408dd06f8ea9e60b412e27a73f0f277bb590cb84','enumerated_source_paths':64,'enumerated_iid_paths':256,'rows':rows,'total_variation_on_partitions':str(tv),'status':'Exact discrepancy in a source-informed transcription; native Julia verification pending; not a failure of the mathematical sampling construction.'}
 (P/'exact-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
