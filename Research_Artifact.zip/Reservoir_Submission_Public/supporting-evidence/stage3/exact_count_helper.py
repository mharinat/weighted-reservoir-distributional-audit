"""Exact piecewise probabilities of the published count shortcut at m=4,p=1/4."""
from fractions import Fraction as Q
from math import comb,factorial
from pathlib import Path
import json
m=4;p=Q(1,4);z=(1-p)**m
pmf=[Q(comb(m,k))*p**k*(1-p)**(m-k) for k in range(m+1)]
cdf=[];acc=Q(0)
for mass in pmf:acc+=mass;cdf.append(acc)
def shortcuts(fixed):
 s=m*p;q=1-p;x=1+s/q;bounds=[z*x]
 for i in range(2,9):
  s*=(m-i+int(fixed))*p;q*=1-p;x+=s/(q*factorial(i));bounds.append(z*x)
 return bounds

def law(fixed):
 bounds=shortcuts(fixed);points=sorted(set([Q(0),Q(1),z]+cdf+[b for b in bounds if 0<=b<=1]));mass=[Q(0)]*5
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2
  if mid<z:k=0
  else:
   k=next((i+1 for i,b in enumerate(bounds) if b>mid),None)
   if k is None:k=next(i for i,b in enumerate(cdf) if b>=mid)
  assert k<=m;mass[k]+=hi-lo
 return mass
source=law(False);repair=law(True);assert repair==pmf
out={'m':m,'p':str(p),'reference':[str(x) for x in pmf],'source':[str(x) for x in source],'count_factor_fixed':[str(x) for x in repair],'tv':str(sum(abs(a-b) for a,b in zip(source,pmf))/2),'source_positive_conditional':[str(x/(1-z)) for x in source[1:]],'reference_positive_conditional':[str(x/(1-z)) for x in pmf[1:]]}
Path(__file__).with_name('exact-count-helper.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
