# Stage 3: source-informed validation artifact

This directory contains historical experimental evidence. Read the current manuscript and supplement in the repository root; superseded drafts and internal review documents are not part of this release.

## Python analyses

Use Python 3.9 with the analysis dependencies pinned in `../stage2/requirements.txt`.

```sh
python exact_audit.py
python exact_grid.py
python exact_count_helper.py
python analyze.py
```

Run these from this directory in an appropriate environment, or use full script paths. The supplied report builder contains interpretation tied to the saved run. Recheck prose manually if generating different measurements. None of these commands contacts an author or submits anything.

## Native Julia checks

Use Julia 1.12.1. The official archive URL and verified SHA256 are in `provenance.json`. Instantiate the supplied Project.toml and Manifest.toml; preserve the dependency versions. From this directory:

```sh
julia --startup-file=no --project=. -e 'using Pkg; Pkg.instantiate()'
env -u RESERVOIR_SOURCE_FILE julia --startup-file=no --project=. native_audit.jl > native-counts.csv
env -u RESERVOIR_SOURCE_FILE julia --startup-file=no --project=. native_extensions.jl equal > native-equal40.csv
env -u RESERVOIR_SOURCE_FILE julia --startup-file=no --project=. native_extensions.jl weighted > native-weighted.csv
env -u RESERVOIR_SOURCE_FILE julia --startup-file=no --project=. native_extensions.jl collisions > native-collisions.csv
env -u RESERVOIR_SOURCE_FILE julia --startup-file=no --project=. native_targets.jl > native-targets.csv
RESERVOIR_SOURCE_FILE="$PWD/upstream/samplers-count-fixed.jl" julia --startup-file=no --project=. native_targets.jl > native-targets-fixed.csv
```

These commands overwrite native result files. Preserve the original artifact before rerunning. `native_audit.jl` defaults to the unchanged upstream file. `get_distinct!` is our separately named source-informed conversion repair. The one-factor-modified upstream file corrects only the count shortcut; its original conversion remains unchanged. Do not label it as a completely repaired library.

The exact Julia runtime used in this workspace is under `work/reservoir-stage3/julia-1.12.1/`; its isolated depot is `work/reservoir-stage3/julia-depot`. Those large runtime files are not included in the research deliverable. The actual validation logs are in the workspace's work directory. No system Julia installation or user's existing Julia environment was changed.

## Retrieval batches

Compile from the workspace root:

```sh
clang++ -std=c++17 -O3 -DNDEBUG outputs/reservoir-replication/stage3/retrieval.cpp -o work/reservoir-stage3/retrieval
work/reservoir-stage3/retrieval > outputs/reservoir-replication/stage3/retrieval-batches.jsonl
```

The driver includes the frozen stage-2 code and renames its unused main function. Clang warns that the unused renamed entry point can fall through without a return; that function is never called. The real driver returns explicitly. The sampler code is unchanged. Run timing alone without compilation, package installation or another heavy workload. This measures warm-cache materialized Get throughput, including returned-vector destruction and a minimal checksum, not borrowed-reference latency.

## Files and limits

- `exact-audit.json`, `exact-grid.json`, `exact-count-helper.json`: exact arithmetic results.
- `native-*.csv`: original native observations, including repair validation and iid controls.
- `analysis.json`: statistics and multiplicity families.
- `retrieval-summary.csv`: batch-level timing uncertainty.
- `author-verification-report.md`: unsent technical report for checking our interpretation.
- `upstream/`: original MIT-licensed source, license notice, and clearly named local count-factor edit.
- `provenance.json`: commit, runtime and source identity.

Historical dependency equality, identity to the figure-generating commit, current-package impact, and novelty of the findings are not established. No author communication or public submission has occurred. Our new research code has not yet been assigned a publication license; the upstream MIT notice applies to the included upstream source.
