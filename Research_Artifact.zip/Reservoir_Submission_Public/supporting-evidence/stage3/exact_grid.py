"""Equal-weight occupancy laws from exact weighted path enumeration."""
from fractions import Fraction as Q
from collections import Counter,defaultdict
from math import factorial
from pathlib import Path
import json
P=Path(__file__).resolve().parent

def part(xs):return tuple(sorted(Counter(xs).values(),reverse=True))
def source_law(N,m):
 law=defaultdict(Q)
 def walk(out,used,prob):
  j=len(out)
  if j==m:law[part(out)]+=prob;return
  for i in range(j):walk(out+[i],used,prob*Q(1,N))
  walk(out+[used],used+1,prob*Q(N-j,N))
 walk([0],1,Q(1));assert sum(law.values())==1;return law

def corrected_law(N,m):
 law=defaultdict(Q)
 def walk(out,used,prob):
  if len(out)==m:law[part(out)]+=prob;return
  for i in range(used):walk(out+[i],used,prob*Q(1,N))
  walk(out+[used],used+1,prob*Q(N-used,N))
 walk([0],1,Q(1));assert sum(law.values())==1;return law

def partitions(n,cap=None):
 if n==0:yield ();return
 for i in range(min(n,cap or n),0,-1):
  for rest in partitions(n-i,i):yield (i,)+rest

def reference(N,m):
 out={}
 for p in partitions(m):
  k=len(p);fall=1
  for j in range(k):fall*=N-j
  den=1
  for n in p:den*=factorial(n)
  for count in Counter(p).values():den*=factorial(count)
  out[p]=Q(fall*factorial(m),N**m*den)
 assert sum(out.values())==1;return out

def main():
 rows=[]
 for m in [2,3,4,5,6,8]:
  for factor in [1,10,100]:
   N=m*factor;a=source_law(N,m);b=reference(N,m);repair=corrected_law(N,m)
   assert all(repair.get(k,0)==v for k,v in b.items())
   tv=sum(abs(a.get(k,0)-v) for k,v in b.items())/2
   rows.append({'N':N,'m':m,'source_partition_tv':str(tv),'source_partition_tv_float':float(tv),'corrected_partition_tv':'0','all_probabilities_exact':True})
 (P/'exact-grid.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
