using Random, DataStructures, Distributions, WeightVectors, StatsBase
import Base: get
include(get(ENV, "RESERVOIR_SOURCE_FILE", joinpath(@__DIR__, "upstream", "samplers.jl")))

# Source-informed repair: expose weights only when a distinct rank is emitted.
# The original upstream get() above remains unmodified and is tested separately.
function get_distinct!(s)
    kvs = sort(s.value.valtree, by=x->x[2][1], rev=true)
    sampler=s.sampler
    for i in eachindex(sampler)
        sampler[i]=0.0
    end
    out=s.samplevalue
    out[1]=kvs[1][1]
    sampler[1]=kvs[1][2][2]
    used=1
    remaining=s.totalw-kvs[1][2][2]
    if s.n>1
        sampler[2]=remaining
    end
    for j in 2:s.n
        i=rand(s.rng,sampler)
        if i<=used
            out[j]=kvs[i][1]
        else
            @assert i==used+1
            used+=1
            out[j]=kvs[used][1]
            sampler[used]=kvs[used][2][2]
            remaining-=kvs[used][2][2]
            if used<s.n
                sampler[used+1]=remaining
            end
        end
    end
    return out
end

const PARTITIONS=[(4,0,0,0),(3,1,0,0),(2,2,0,0),(2,1,1,0),(1,1,1,1)]
function occupancy(x)
    return Tuple(sort([count(==(i),x) for i in 1:4],rev=true))
end
function runaudit()
    reps=1_000_000
    println("method,partition,count,repetitions")
    for (method,seed) in [("original",971), ("corrected",972), ("iid",973)]
        rng=Xoshiro(seed)
        sampler=ReservoirSampler{Int}(rng,4,AlgWRAExpJ())
        for i in 1:4
            add!(sampler,i,1.0)
        end
        counts=zeros(Int,5)
        for r in 1:reps
            sample=method=="original" ? get(sampler) : method=="corrected" ? get_distinct!(sampler) : rand(rng,1:4,4)
            k=findfirst(==(occupancy(sample)),PARTITIONS)
            counts[k]+=1
        end
        for k in 1:5
            println(method,",",join(PARTITIONS[k],"-"),",",counts[k],",",reps)
        end
    end
end
if abspath(PROGRAM_FILE)==@__FILE__
    runaudit()
end
