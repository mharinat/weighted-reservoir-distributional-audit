#define main stage2_main
#include "../stage2/experiment.cpp"
#undef main
int main(){try{
 RNG order(73842);int N=100000;
 for(int pattern=0;pattern<3;++pattern){std::vector<double>w(N);for(int i=0;i<N;++i)w[i]=pattern==0?1./(i+1):pattern==1?1.:i+1.;
  for(int m:{10,100,1000,10000})for(int rep=0;rep<20;++rep){std::array<int,3>algs={1,2,3};std::shuffle(algs.begin(),algs.end(),order);
   for(int a:algs){Sampler s(Mode(a),m,99100+rep);for(double x:w)s.add(x);{auto v=s.get();sink+=v.front();}
    auto start=Clock::now();for(int j=0;j<100;++j){auto v=s.get();sink+=uint64_t(v.front())+uint64_t(v.back());}double batch=elapsed(start);
    if(!(batch>0))throw std::runtime_error("nonpositive batch duration");
    std::cout<<std::setprecision(17)<<"{\"N\":"<<N<<",\"m\":"<<m<<",\"pattern\":"<<pattern<<",\"rep\":"<<rep<<",\"algorithm\":\""<<names[a]<<"\",\"calls\":100,\"batch_seconds\":"<<batch<<",\"per_call_seconds\":"<<batch/100<<"}\n";
   }
  }
 }return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
