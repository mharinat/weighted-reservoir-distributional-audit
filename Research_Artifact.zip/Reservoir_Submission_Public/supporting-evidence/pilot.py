"""Independent feasibility implementation from paper pseudocode; not final benchmark."""
import json, math, platform, time, hashlib
from pathlib import Path
import numpy as np
from scipy.stats import chisquare, t
import scipy
ROOT=Path(__file__).resolve().parent

def positive_binomial(m,p,rng):
    if p >= 1: return m
    a=-math.expm1(m*math.log1p(-p))
    if a > .25:
        k=0
        while k==0: k=int(rng.binomial(m,p))
        return k
    # Conditional inverse CDF; stable because this branch has small m*p.
    prob=m*p*math.exp((m-1)*math.log1p(-p))/a
    u=float(rng.random()); k=1; acc=prob
    while u>acc and k<m:
        prob*=((m-k)/(k+1))*p/(1-p)
        k+=1; acc+=prob
    return k

def sample(weights,m,rng,mode):
    it=iter(weights); W=float(next(it)); r=np.zeros(m,dtype=np.int64)
    threshold=W/math.exp(math.log(1-float(rng.random()))/m) if mode=='skip' else 0.
    for i,w in enumerate(it,1):
        w=float(w);W+=w;p=w/W
        if mode=='bernoulli':
            r[rng.random(m)<p]=i
        elif mode=='bin':
            k=int(rng.binomial(m,p))
            if k:r[rng.choice(m,k,replace=False)]=i
        elif W>=threshold:
            threshold=W/math.exp(math.log(1-float(rng.random()))/m)
            k=positive_binomial(m,p,rng)
            r[rng.choice(m,k,replace=False)]=i
    return r

def main():
    started=time.perf_counter(); rows=[]
    for c,w in enumerate(([1,2,3],[3,2,1],[1,1,1])):
        p=np.array(w)/sum(w);expected=np.outer(p,p).ravel()*20000
        for a,mode in enumerate(('bernoulli','bin','skip')):
            rng=np.random.default_rng(103000+10*c+a);counts=np.zeros(9,dtype=int)
            for _ in range(20000):
                r=sample(w,2,rng,mode);counts[3*r[0]+r[1]]+=1
            stat,pvalue=chisquare(counts,expected)
            rows.append(dict(weights=w,algorithm=mode,replicates=20000,counts=counts.tolist(),expected=expected.tolist(),chi2=float(stat),p=float(pvalue)))
    ordered=sorted(range(len(rows)),key=lambda i:rows[i]['p']);last=0
    for j,i in enumerate(ordered):
        last=max(last,min(1,(len(rows)-j)*rows[i]['p']));rows[i]['p_holm']=last
    timing=[];order=np.random.default_rng(9901)
    for kind in ('decreasing','constant','increasing'):
        x=np.arange(1,10001,dtype=float);w=1/x if kind=='decreasing' else np.ones(10000) if kind=='constant' else x
        for m in (10,100):
            for mode in ('bin','skip'):sample(w,m,np.random.default_rng(5),mode)
            values={'bin':[],'skip':[]}
            for rep in range(5):
                for mode in order.permutation(['bin','skip']):
                    rng=np.random.default_rng(500+rep);start=time.perf_counter();sample(w,m,rng,mode)
                    values[mode].append(time.perf_counter()-start)
            for mode,v in values.items():
                mean=float(np.mean(v));sd=float(np.std(v,ddof=1));half=float(t.ppf(.975,4)*sd/math.sqrt(5))
                timing.append(dict(distribution=kind,n=10000,m=m,algorithm=mode,seconds=v,mean=mean,sd=sd,ci95=[mean-half,mean+half]))
    result=dict(status='feasibility_only',python=platform.python_version(),platform=platform.platform(),numpy=np.__version__,scipy=scipy.__version__,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),correctness=rows,timing=timing,total_seconds=time.perf_counter()-started)
    (ROOT/'pilot-results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'total_seconds':result['total_seconds'],'min_p_holm':min(x['p_holm'] for x in rows),'timings':[{k:r[k] for k in ('distribution','m','algorithm','mean')} for r in timing]},indent=2))
if __name__=='__main__':main()
