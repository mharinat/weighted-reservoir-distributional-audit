# Manuscript preparation, stage 6

This directory contains historical experimental evidence. Read the current manuscript and supplement in the repository root; superseded drafts and internal review documents are not part of this release.

- `directives-assessment-ar.md`: applicability, implemented requirements, exceptions and outstanding work.
- `conversion-invariant.md`: conditional proof of the conceptual conversion repair; no novelty claim.
- `exact_weighted_conversion.py` and `exact-weighted-results.json`: 19 exact weighted ordered-output checks. These are source-informed mathematical transcriptions, not fresh Julia executions.
- `followup_uncertainty.py` and `followup-uncertainty.csv`: added marginal MSE bootstrap and coverage Wilson intervals using saved stage-5 outputs.
- `preparation-validation.json`: targeted number and figure-link checks.

Use the same Python dependencies as stage 5. From this directory:

```sh
python exact_weighted_conversion.py
python followup_uncertainty.py
```

The latter command requires `../stage5/impact-followup.csv`. Run in a copy to preserve the supplied outputs. The new proof depends on strictly positive weights, exact arithmetic and the correct size-biased key order. It does not certify floating-point code for every input. The added bootstrap analysis is retrospective and descriptive; no new confirmatory claim follows from it.

No public upload, journal submission, additional author message or clean-environment build occurred in this batch. Earlier manifest files describe their historical coverage; the stage-6 manifest covers these additions separately.
