from pathlib import Path
import numpy as np,pandas as pd
from scipy import stats
P=Path(__file__).resolve().parent;D=pd.read_csv(P.parent/'stage5/impact-followup.csv');rng=np.random.default_rng(665048)
rows=[]
for method,g in D.groupby('method'):
 x=g.squared_error.to_numpy()/g.iid_mean_variance.iloc[0];n=len(x);bs=[]
 for _ in range(50):bs.extend(x[rng.integers(n,size=(100,n))].mean(axis=1))
 lo,hi=np.quantile(bs,[.025,.975]);c=g.covered.mean();z=stats.norm.ppf(.975);den=1+z*z/n;center=(c+z*z/(2*n))/den;half=z*np.sqrt(c*(1-c)/n+z*z/(4*n*n))/den
 rows.append(dict(method=method,mse_ratio=x.mean(),mse_ratio_lo=lo,mse_ratio_hi=hi,coverage=c,coverage_lo=center-half,coverage_hi=center+half))
pd.DataFrame(rows).to_csv(P/'followup-uncertainty.csv',index=False);print(pd.DataFrame(rows).to_string(index=False))
