# Correctness invariant for distinct-rank conversion

This is a justification of the local repair using the established weighted sampling construction, not a claim to a new sampling algorithm.

Assume $N\geq m\geq1$, strictly positive finite weights $w_i$, total $W=\sum_iw_i$, exact arithmetic, and an ordered reservoir containing the first $m$ elements of a size-biased random permutation $R$. Its conditional rank law is

$$\Pr(R_{k+1}=i\mid R_1,\ldots,R_k)=\frac{w_i}{W-\sum_{j=1}^{k}w_{R_j}}$$

for every not-yet-revealed label $i$. Independent exponential keys with rates $w_i$, sorted in ascending order, have this law: the minimum has probability $w_i/W$, and memorylessness gives the same argument after each removal. Distinct tie-free keys and correctly retained top ranks are assumptions; this statement does not verify all floating-point reservoir implementations.

The repaired conversion emits $R_1$ first. After $t$ outputs, let $U_t$ be the set of distinct emitted items and $k=|U_t|$. Its invariant is $U_t=\{R_1,\ldots,R_k\}$. The dynamic sampler holds weight $w_i$ for each $i\in U_t$ and one residual category with weight $W-\sum_{i\in U_t}w_i$. A repeat leaves $k$ unchanged. A residual draw emits $R_{k+1}$ and increments $k$; the newly exposed item's weight is transferred from the residual category to its own category.

Condition on the output history. Its repeat and residual decisions depend only on the revealed prefix and fresh auxiliary draws; they reveal no extra information about the order of the unseen suffix. A seen item has next-output probability $w_i/W$. An unseen item has probability

$$\frac{W-\sum_{j\in U_t}w_j}{W}\cdot\frac{w_i}{W-\sum_{j\in U_t}w_j}=\frac{w_i}{W}.$$

Therefore each next conditional law equals the target weighted law. Induction gives

$$\Pr(X_1=x_1,\ldots,X_m=x_m)=\prod_{t=1}^{m}\frac{w_{x_t}}W.$$

At most $m$ ranks are needed because there are only $m$ outputs. This proves the corrected conceptual converter under the stated assumptions, rather than deriving correctness merely from a non-rejected Monte Carlo test. Its count vector consequently has the required multinomial distribution. Reusing one fixed weighted reservoir for arbitrary sample-mean inference does not meet the unconditional rank assumption; the impact experiments rebuild each reservoir.

The original position-based category activation breaks the invariant: a rank can become selectable before it advances the distinct-rank pointer. The local repair makes category activation follow $k$, not $t$.

The converter requires $\mathcal O(m)$ auxiliary storage. With expected constant-time dynamic draws and updates, conversion after sorting is expected $\mathcal O(m)$; the comparison artifact also sorts its $m$ heap entries, for a conventional $\mathcal O(m\log m)$ comparison-sort bound. Exact enumeration in `exact_weighted_conversion.py` integrates the conceptual rank law over full permutations for small $N$. A conservative bound is $\mathcal O(N!\,m!\,(N+m))$ arithmetic work plus the $\mathcal O(mN^m)$ iid reference construction, excluding rational bit costs. The executed cases have $N\leq5$ and are audit checks, not scalable samplers.
