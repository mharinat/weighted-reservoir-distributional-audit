"""Exact ordered-output laws integrated over size-biased key permutations.
Source-informed transcription; conditional key-order assumption is explicit.
No Monte Carlo samples or upstream code imports.
"""
from fractions import Fraction as F
from itertools import permutations,product
from collections import defaultdict,Counter
from pathlib import Path
from math import factorial
import json
P=Path(__file__).resolve().parent

def distribution(w,m,fixed):
 W=sum(w);law=defaultdict(F)
 for order in permutations(range(len(w))):
  prob=F(1);remaining=W
  for i in order:prob*=F(w[i],remaining);remaining-=w[i]
  def walk(out,used,mass):
   if len(out)==m:law[tuple(out)]+=mass;return
   k=used if fixed else len(out)
   for rank in range(k):walk(out+[order[rank]],used,mass*F(w[order[rank]],W))
   residual=W-sum(w[order[r]] for r in range(k))
   if residual:walk(out+[order[used]],used+1,mass*F(residual,W))
  walk([order[0]],1,prob)
 assert sum(law.values())==1
 return law

def counts(law,n):
 d=defaultdict(F)
 for x,p in law.items():d[tuple(x.count(i) for i in range(n))]+=p
 return d

def main():
 cases=[]
 for w in [(1,1,1),(1,2,3),(1,1,1,1),(1,2,3,4),(4,3,2,1),(1,10,100,1000),(1,2,3,4,5)]:
  for m in sorted(set([2,3,len(w)])):
   n=len(w);ref={x:F(1) for x in product(range(n),repeat=m)}
   for x in ref:
    for i in x:ref[x]*=F(w[i],sum(w))
   original=distribution(w,m,False);repair=distribution(w,m,True)
   assert all(repair.get(x,F(0))==p for x,p in ref.items())
   tv=sum(abs(original.get(x,F(0))-p) for x,p in ref.items())/2
   a=counts(original,n);b=counts(ref,n);ctv=sum(abs(a.get(x,F(0))-p) for x,p in b.items())/2
   cases.append(dict(weights=list(w),N=n,m=m,ordered_states=n**m,key_permutations=factorial(n),source_ordered_tv=str(tv),source_count_tv=str(ctv),repair_ordered_tv='0'))
 (P/'exact-weighted-results.json').write_text(json.dumps(cases,indent=2)+'\n');print('Cases:',len(cases),'all repaired ordered laws exact; original discrepancies:',sum(F(x['source_ordered_tv'])>0 for x in cases))
if __name__=='__main__':main()
