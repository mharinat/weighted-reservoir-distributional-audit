from pathlib import Path
import numpy as np,pandas as pd,json
from scipy import stats
P=Path(__file__).resolve().parent;D=pd.read_csv(P/'helper-moments.csv');assert len(D)==20
D['sd']=np.sqrt(D.variance);se=D.sd/np.sqrt(D.repetitions);t=(D['mean']-D.theory_mean)/se
D['lo']=D['mean']-stats.t.ppf(.975,D.repetitions-1)*se;D['hi']=D['mean']+stats.t.ppf(.975,D.repetitions-1)*se
D['p_value']=2*stats.t.sf(abs(t),D.repetitions-1);ix=np.argsort(D.p_value);adj=np.empty(len(D));adj[ix]=np.minimum(1,np.maximum.accumulate(D.p_value.to_numpy()[ix]*(len(D)-np.arange(len(D)))));D['p_holm']=adj
D.to_csv(P/'helper-summary.csv',index=False)
print(D[['version','p','kind','mean','theory_mean','p_holm']].to_string(index=False))
