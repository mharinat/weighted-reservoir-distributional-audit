from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import csv,json
P=Path(__file__).resolve().parent

def law(n,p,fixed):
 pmf=[F(comb(n,k))*p**k*(1-p)**(n-k) for k in range(n+1)]
 cdf=[];s=F(0)
 for a in pmf:s+=a;cdf.append(s)
 z=pmf[0];s=n*p;q=1-p;x=1+s/q;bounds=[z*x]
 for i in range(2,9):
  s*=(n-i+int(fixed))*p;q*=1-p;x+=s/(q*factorial(i));bounds.append(z*x)
 out=[F(0)]*(n+1);out[0]=z;cur=z
 for i,b in enumerate(bounds,1):
  end=min(F(1),max(cur,b))
  if end>cur:
   assert i<=n,(n,p,fixed,i)
   out[i]+=end-cur;cur=end
 for k,b in enumerate(cdf):
  lo=max(cur,cdf[k-1] if k else F(0))
  if b>lo:out[k]+=b-lo
 assert sum(out)==1
 return out,pmf
rows=[]
for n in range(1,51):
 ps={F(1,20),F(1,4),F(1,2),F(3,4),F(19,20)}
 if n>=2:ps.add(F(1,n))
 for p in sorted(ps):
  a,t=law(n,p,False);b,_=law(n,p,True);assert b==t
  tv=sum(abs(x-y) for x,y in zip(a,t))/2
  rows.append(dict(n=n,p=str(p),source_tv=str(tv),source_tv_float=float(tv),truncated_tv=str(tv/(1-t[0])),repair_tv='0'))
with (P/'exact-shortcut-grid.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(P/'exact-shortcut-validation.json').write_text(json.dumps({'cells':len(rows),'ordinary_and_truncated_repaired_exact':True,'nonzero_source_cells':sum(F(r['source_tv'])>0 for r in rows),'arithmetic':'exact rational; excludes floating-point error'},indent=2))
print('Exact cells',len(rows),'all repairs equal reference')
