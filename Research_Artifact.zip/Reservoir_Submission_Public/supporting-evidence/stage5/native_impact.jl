include(joinpath(@__DIR__,"..","stage3","native_audit.jl"))
using Dates
function metrics(x,N,mu,v,m)
 y=sum(x)/(N*m);err=y-mu;d=Dict{Int,Int}();pairs=0
 for a in x;c=get(d,a,0);pairs+=c;d[a]=c+1;end
 return (y,err^2,abs(err)<=1.959963984540054*sqrt(v/m),pairs)
end
function main()
 println("N,m,pattern,rep,method,mean,squared_error,covered,collisions,population_mean,iid_mean_variance")
 for N in [10000,100000], pattern in ["uniform","increasing"]
  m=1000;w=pattern=="uniform" ? ones(N) : Float64.(1:N);cdf=cumsum(w);cdf./=cdf[end]
  mu=sum((i/N)*w[i] for i in 1:N)/sum(w);v=sum((i/N-mu)^2*w[i] for i in 1:N)/sum(w)
  for r in 1:3000
   seed=900000+10*r;s=ReservoirSampler{Int}(Xoshiro(seed),m,AlgWRAExpJ())
   for i in 1:N;add!(s,i,w[i]);end
   for (method,offset) in [("original",1),("corrected",2),("iid",3)]
    Random.seed!(s.rng,seed+offset)
    x=method=="original" ? get(s) : method=="corrected" ? get_distinct!(s) : [searchsortedfirst(cdf,rand(s.rng)) for _ in 1:m]
    vals=metrics(x,N,mu,v,m)
    println(join((N,m,pattern,r,method,vals...,mu,v/m),","))
   end
   if r%500==0;flush(stdout);println(stderr,Dates.now()," N=",N," pattern=",pattern," rep=",r);flush(stderr);end
  end
 end
end
main()
