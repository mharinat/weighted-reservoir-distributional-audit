using Random,Statistics
module Original
using Random,DataStructures,Distributions,WeightVectors,StatsBase
import Base:get
include(joinpath(@__DIR__,"..","stage3","upstream","samplers.jl"))
end
module Fixed
using Random,DataStructures,Distributions,WeightVectors,StatsBase
import Base:get
include(joinpath(@__DIR__,"..","stage3","upstream","samplers-count-fixed.jl"))
end
include(joinpath(@__DIR__,"..","stage4","conversion_repair.jl"))
function main()
 println("kind,version,case,algorithm,status,detail")
 for (version,M) in [("original",Original),("repaired",Fixed)]
  for (case,w,m) in [("short_stream",[1.,2.],4),("equal_size",ones(4),4),("dynamic_range",[1e12,1.,1.,1.,1.,1.,1.,1.],4),("zero_first",[0.,1.,1.,1.,1.,1.,1.,1.],4)]
   for alg in ["BIN","SKIP","EXPJ"]
    # EXPJ Get assumes a full reservoir; avoid unsafe unchecked indexing of a partial heap.
    if case=="short_stream" && alg=="EXPJ"
     println("boundary,",version,",",case,",",alg,",not_executed,partial heap unchecked indexing");continue
    end
    try
     a=alg=="BIN" ? M.AlgWRSWRBIN() : alg=="SKIP" ? M.AlgWRSWRSKIP() : M.AlgWRAExpJ()
     s=M.ReservoirSampler{Int}(Xoshiro(41),m,a)
     for i in eachindex(w);M.add!(s,i,w[i]);end
     x=version=="repaired" && alg=="EXPJ" ? get_distinct!(s) : get(s)
     ok=length(x)==m && all(a->1<=a<=length(w),x)
     println("boundary,",version,",",case,",",alg,",",ok ? "valid_shape" : "invalid_shape",",",join(x,"-"))
    catch e
     println("boundary,",version,",",case,",",alg,",exception,",replace(sprint(showerror,e),','=>';','\n'=>' '))
    end
   end
  end
 end
 open(joinpath(@__DIR__,"helper-moments.csv"),"w") do io
  println(io,"version,n,p,kind,repetitions,mean,variance,theory_mean,theory_variance")
  for (version,M) in [("original",Original),("repaired",Fixed)], p in [.0002,.001,.004,.016,.9],kind in ["ordinary","positive"]
   n=1000;R=200000;rng=Xoshiro(71291);f=kind=="ordinary" ? M.choose_with_0 : M.choose
   x=[f(rng,n,p) for _ in 1:R];a=-expm1(n*log1p(-p));mu=kind=="ordinary" ? n*p : n*p/a;v=kind=="ordinary" ? n*p*(1-p) : (n*p*(1-p)+(n*p)^2)/a-mu^2
   println(io,join((version,n,p,kind,R,mean(x),var(x),mu,v),","));flush(io)
  end
 end
end
main()
