from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib,datetime
P=Path(__file__).resolve().parent;U=P/'history';U.mkdir(exist_ok=True)
base='https://api.github.com/repos/JuliaDynamics/StreamSampling.jl'
def fetch(url):
 with urlopen(Request(url,headers={'User-Agent':'independent-replication-audit'}),timeout=45) as f:return f.read()
repo=json.loads(fetch(base));branch=repo['default_branch'];head=json.loads(fetch(base+'/commits/'+branch));commits=[]
for page in range(1,101):
 data=json.loads(fetch(base+'/commits?path=comparison/samplers.jl&per_page=100&page='+str(page)));commits+=data
 if len(data)<100:break
else:raise RuntimeError('pagination limit')
(U/'commits.json').write_text(json.dumps(commits,indent=2));(U/'head.json').write_text(json.dumps(head,indent=2))
pinned=(P.parent/'stage3/upstream/samplers.jl').read_bytes();rows=[]
for sha,date,kind in [(head['sha'],head['commit']['committer']['date'],'HEAD')]+[(c['sha'],c['commit']['committer']['date'],'file-history') for c in commits]:
 data=fetch('https://raw.githubusercontent.com/JuliaDynamics/StreamSampling.jl/'+sha+'/comparison/samplers.jl');(U/(sha+'.jl')).write_bytes(data)
 text=data.decode();rows.append(dict(sha=sha,date=date,kind=kind,sha256=hashlib.sha256(data).hexdigest(),identical_to_pinned=data==pinned,count_bad_factor='($(esc(:n)) - $i)' in text,conversion_position_category='sampler[j] = kvs[j]' in text))
(P/'history.json').write_text(json.dumps({'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':branch,'file_commits':len(commits),'rows':rows},indent=2));print(json.dumps(rows,indent=2))
