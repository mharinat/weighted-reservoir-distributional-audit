from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;D=pd.read_csv(P.parent/'stage4/performance.csv');rng=np.random.default_rng(543091)
def holm(p):
 p=np.array(p);ix=np.argsort(p);a=np.empty(len(p));a[ix]=np.minimum(1,np.maximum.accumulate(p[ix]*(len(p)-np.arange(len(p)))));return a
def blocks(z,L):
 n=len(z);starts=rng.integers(0,n,size=(5000,int(np.ceil(n/L))));ix=((starts[:,:,None]+np.arange(L))%n).reshape(5000,-1)[:,:n]
 return np.exp(np.quantile(z[ix].mean(axis=1),[.025,.975]))
rows=[]
for version in ['original','repaired']:
 for key,g in D[D.version==version].groupby(['N','m','pattern']):
  t=g.pivot(index='rep',columns='algorithm',values='add_seconds').sort_index()
  for base in ['BIN','EXPJ']:
   ratios=(t.SKIP/t[base]).to_numpy();z=np.log(ratios);r=dict(zip(['N','m','pattern'],key),version=version,baseline=base,median=np.median(ratios),q25=np.quantile(ratios,.25),q75=np.quantile(ratios,.75),all_faster=bool((ratios<1).all()),sign_p=stats.binomtest(int((ratios<1).sum()),len(z),.5).pvalue,lag1=np.corrcoef(z[:-1],z[1:])[0,1])
   for L in [1,2,4,5]:r[f'block{L}_lo'],r[f'block{L}_hi']=blocks(z,L)
   rows.append(r)
A=pd.DataFrame(rows)
for v in ['original','repaired']:A.loc[A.version==v,'sign_p_holm']=holm(A[A.version==v].sign_p)
A.to_csv(P/'timing-sensitivity.csv',index=False)
R=[]
for key,g in D.groupby(['N','m','pattern','algorithm']):
 t=g.pivot(index='rep',columns='version',values='add_seconds').sort_index();z=np.log(t.repaired/t.original).to_numpy();r=dict(zip(['N','m','pattern','algorithm'],key),median_ratio=np.median(np.exp(z)))
 for L in [1,2,4,5]:r[f'block{L}_lo'],r[f'block{L}_hi']=blocks(z,L)
 for margin in [.05,.1]:r[f'interval_within_{margin}']=all(r[f'block{L}_lo']>=1-margin and r[f'block{L}_hi']<=1+margin for L in [1,2,4,5])
 R.append(r)
V=pd.DataFrame(R);V.to_csv(P/'repair-sensitivity.csv',index=False)
fig,axs=plt.subplots(2,3,figsize=(11,7),sharey=True,sharex=True)
for row,N in enumerate([1000000,10000000]):
 for col,pat in enumerate([0,1,2]):
  ax=axs[row,col];d=D[(D.N==N)&(D.pattern==pat)&(D.version=='repaired')]
  for j,base in enumerate(['BIN','EXPJ']):
   for k,(m,g) in enumerate(d.groupby('m')):
    t=g.pivot(index='rep',columns='algorithm',values='add_seconds');y=t.SKIP/t[base];x=k+(j-.5)*.23
    ax.scatter(x+np.linspace(-.035,.035,len(y)),y,s=12,alpha=.5,color=['#1769aa','#c34d13'][j],label=base if k==0 else None)
    ax.plot([x-.07,x+.07],[y.median()]*2,color='black',lw=2)
  ax.axhline(1,color='gray',ls='--');ax.set_yscale('log');ax.set_title(f'N={N:,}, '+['w=1/i','w=1','w=i'][pat]);ax.grid(alpha=.2)
  ax.set_xticks(range(4),['0.0001','0.001','0.01','0.1'])
  if row==1:ax.set_xlabel('Reservoir fraction m/N')
  if col==0:ax.set_ylabel('Paired Add time: SKIP / comparator')
axs[0,0].legend(title='Comparator');fig.tight_layout();fig.savefig(P/'timing-raw-ratios.png',dpi=170);plt.close(fig)
summary={'contrasts_each_version':48,'repaired_all_20_pairs_faster':int(A[A.version=='repaired'].all_faster.sum()),'repaired_all_block_upper_below_one':int((A[A.version=='repaired'][[f'block{L}_hi' for L in [1,2,4,5]]]<1).all(axis=1).sum()),'repair_intervals_within_10_percent':V.groupby('algorithm')['interval_within_0.1'].sum().to_dict(),'interpretation':'Exploratory block-length sensitivity; does not establish stationarity or independence.'}
(P/'timing-validation.json').write_text(json.dumps(summary,indent=2));print(summary)
