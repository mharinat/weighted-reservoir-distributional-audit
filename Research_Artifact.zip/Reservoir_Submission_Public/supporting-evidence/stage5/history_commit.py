from urllib.request import Request,urlopen
from pathlib import Path
import json
p=Path(__file__).resolve().parent
url='https://api.github.com/repos/JuliaDynamics/StreamSampling.jl/commits/686fa7aba586bbd02a7d9b1173eed245bf12f089'
with urlopen(Request(url,headers={'User-Agent':'replication-audit'}),timeout=30) as f:d=json.load(f)
(p/'history/file-introduction-commit.json').write_text(json.dumps(d,indent=2))
print([(f['filename'],f['status']) for f in d['files'] if f['filename']=='comparison/samplers.jl'])
