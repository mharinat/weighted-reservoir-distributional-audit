# Preserved stage-4 timing analysis

Historical report; confidence intervals require the qualifications in manuscript v5.

### Corrected native performance

The full design crosses $N\in\{10^6,10^7\}$, $m/N\in\{10^{-4},10^{-3},10^{-2},10^{-1}\}$, three weight sequences, three methods and two code versions. Each cell has 20 replicates. All 2,880 records are retained. The six-record pilot is excluded. A protocol arithmetic error initially listed 1,440 records; the specified grid was unchanged and its correct product was recorded before analysis.

Julia 1.12.1 ran with one thread on an Apple M3 with 16 GiB RAM and macOS 27.0.1. Weight generation and sampler construction are outside Add timing; processing includes initialization performed by Add. Each method/version specialization is warmed on a full stream before measurement. Job order is shuffled within each configuration/replicate. The sampler seed is $71000+r$ for replicate $r$, and the scheduling RNG seed is 413008. Normal garbage collection remains enabled. The available host can run background user or OS work, which was not controlled. No CPU-intensive analysis was deliberately run concurrently.

For each paired contrast, $z_r=\log(t_{a,r}/t_{b,r})$. The reported ratio is $\exp(\bar z)$, with marginal 95% interval $\exp(\bar z\pm t_{0.975,19}s_z/\sqrt{20})$. Two-sided one-sample $t$ tests on $z_r$ are adjusted by Holm within the prespecified 72-contrast version family or 48-contrast method family. Intervals are not simultaneous familywise intervals. Same-seed pairing aligns replicate labels but does not imply identical random-number consumption. Consecutive runs on one device can share thermal or scheduling effects; p-values describe this run and are not population-wide performance guarantees.

![Native corrected processing](../stage4/native-performance.png)

Figure 3. Repaired native Add time. Error bars are marginal 95% intervals for arithmetic mean time over 20 runs. Means, sample SDs, intervals, GC durations and raw records are supplied in the artifact.

Repaired SKIP/BIN ratios range from 0.094 to 0.554; 24 configurations favour SKIP after correction for multiple tests. SKIP/EXPJ ratios range from 0.140 to 0.751, with 24 faster, 0 slower and 0 undetected contrasts. The complete ten-million-item subset follows; a ratio below one favours SKIP.

| Weights | $m/N$ | SKIP/BIN ratio [95% CI]; adjusted $p$ | SKIP/EXPJ ratio [95% CI]; adjusted $p$ |
|---|---:|---|---|
| $1/i$ | 0.0001 | 0.327 [0.257, 0.416]; 1.21e-07 | 0.670 [0.527, 0.853]; 0.00501 |
| $1/i$ | 0.001 | 0.223 [0.158, 0.315]; 2.73e-07 | 0.441 [0.312, 0.624]; 0.000461 |
| $1/i$ | 0.01 | 0.252 [0.191, 0.334]; 5.95e-08 | 0.378 [0.284, 0.503]; 8.88e-06 |
| $1/i$ | 0.1 | 0.301 [0.289, 0.315]; 2.01e-21 | 0.140 [0.134, 0.146]; 4.31e-25 |
| $1$ | 0.0001 | 0.094 [0.079, 0.113]; 2.69e-15 | 0.198 [0.166, 0.235]; 9.33e-13 |
| $1$ | 0.001 | 0.118 [0.105, 0.133]; 6.56e-18 | 0.221 [0.199, 0.246]; 6.13e-16 |
| $1$ | 0.01 | 0.253 [0.243, 0.263]; 4.63e-23 | 0.278 [0.267, 0.289]; 2.02e-22 |
| $1$ | 0.1 | 0.513 [0.503, 0.522]; 2.54e-23 | 0.268 [0.261, 0.274]; 5.81e-27 |
| $i$ | 0.0001 | 0.096 [0.082, 0.112]; 2.1e-16 | 0.193 [0.166, 0.226]; 1.26e-13 |
| $i$ | 0.001 | 0.153 [0.136, 0.174]; 1.7e-16 | 0.258 [0.226, 0.294]; 2.07e-13 |
| $i$ | 0.01 | 0.336 [0.330, 0.342]; 1.16e-27 | 0.298 [0.292, 0.303]; 2.4e-28 |
| $i$ | 0.1 | 0.535 [0.522, 0.548]; 1.11e-20 | 0.266 [0.262, 0.271]; 3.33e-30 |

The Add repair/original comparisons are:

| Method | Ratio range | Faster | Slower | Not detected |
|---|---:|---:|---:|---:|
| BIN | 0.896–1.033 | 0 | 3 | 21 |
| EXPJ | 0.980–1.016 | 0 | 0 | 24 |
| SKIP | 0.789–1.282 | 0 | 0 | 24 |

The EXPJ repair changes only Get, leaving its Add algorithm unchanged. Its Add contrasts therefore function as a control for execution variability, compiler-module effects and runtime state rather than a causal repair-speed claim. BIN and SKIP change a shared count factor and can consequently consume different random trajectories; their ratios combine arithmetic and trajectory effects. A non-significant timing difference does not establish equivalence.

The expected mechanism behind SKIP's processing advantage at small reservoir fractions is reduced update work while the stream scan remains mandatory. Increasing weights increase the relative mass of arriving elements compared with decreasing weights, changing update frequency. Figure 3 describes these associations; no separate hardware-counter or event-count experiment isolates their individual runtime contribution.

Get returns a stored reference for BIN/SKIP and performs sorting plus conversion for EXPJ. BIN/SKIP batches contain 1,000 calls; EXPJ batches contain $\max(1,\min(20,\lfloor10000/m\rfloor))$ calls. A noinline wrapper and observable checksum are included. This warm-cache interface measurement must not be read as the cost of allocating an independent output copy. The wrapper can dominate reference-return timing, so nanosecond differences between BIN and SKIP Get are not tested. Correctness diagnostics support the repairs in their tested cases; timing a large configuration is not an additional distributional validation of that configuration.

