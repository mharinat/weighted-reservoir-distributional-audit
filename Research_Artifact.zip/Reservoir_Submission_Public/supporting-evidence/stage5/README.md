# Stage 5: review-triggered revision

This directory contains historical experimental evidence. Read the current manuscript and supplement in the repository root; superseded drafts and internal review documents are not part of this release.

## Environment

Julia 1.12.1, one thread, with the saved Project/Manifest in `../stage3`. Python environment as stage 4: NumPy 2.0.2, pandas 2.2.3, SciPy 1.13.1, matplotlib 3.9.4. No paid service or external dataset is needed. History retrieval requires public GitHub access.

## Reproduction commands

Run in a copy to preserve supplied data. Set `JULIA_DEPOT_PATH` to a suitable instantiated depot if needed. From this directory:

```sh
python history.py
python history_commit.py
python exact_shortcut.py
python timing_sensitivity.py
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_impact.jl > impact.csv
python analyze_impact.py
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_boundaries.jl > boundaries.csv
python analyze_helpers.py
JULIA_NUM_THREADS=1 julia --startup-file=no --project=../stage3 native_followup.jl > impact-followup.csv
python analyze_followup.py
```

The follow-up was selected after primary results; it must not be portrayed as an unselected confirmatory population survey. Preserve `protocol.md`, `pre-execution.json` and `followup-pre-execution.json`. The first hash record refers to the protocol before its appended amendment; the separately saved initial protocol allows verification. Local timestamps are not independently verifiable preregistration. Analysis-script hashes were not publicly registered before the runs.

## Main artifacts

- `history.json` plus `history/`: fetched metadata and source snapshots. Path history is distinct from all-branch/rename history.
- `exact-shortcut-grid.csv` and `count-repair-proof.md`: 296 exact parameter combinations and exact-arithmetic proof.
- `impact.csv`: 36,000 output records on 12,000 fresh reservoirs plus 12,000 iid controls; each reservoir yields original and repaired output.
- `impact-followup.csv`: 60,000 output records on 20,000 fresh reservoirs plus 20,000 iid controls.
- `impact-summary.csv`, `impact-paired.csv`, `followup-summary.csv`, `followup-paired.json`: estimator effects and uncertainty.
- `helper-moments.csv`, `helper-summary.csv`: 20 cells of 200,000 native count draws each; aggregate moments and mean-test results.
- `timing-sensitivity.csv`, `repair-sensitivity.csv`, `timing-raw-ratios.png`: existing-timing sensitivity, not fresh timing experiments.
- `boundaries.csv`: shape and exception diagnostics; not full distribution tests.

Bootstrap reproducibility uses explicit NumPy seeds. Direct Julia samples use Xoshiro and deterministic seeds. Within-configuration reservoirs are independently rebuilt; original and repaired queries share each reservoir. Seed reuse across configurations is recorded in the protocol. No precision or performance claim extends beyond the declared cases.
