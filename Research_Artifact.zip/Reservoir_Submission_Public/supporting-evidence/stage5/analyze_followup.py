from pathlib import Path
import json
import pandas as pd,numpy as np
from scipy import stats
P=Path(__file__).resolve().parent;D=pd.read_csv(P/'impact-followup.csv');assert len(D)==60000;assert D.groupby('method').size().eq(20000).all()
def estimate(x,ref=0):
 x=np.asarray(x);se=stats.sem(x);h=stats.t.ppf(.975,len(x)-1)*se
 return dict(mean=x.mean(),sd=x.std(ddof=1),lo=x.mean()-h,hi=x.mean()+h,p=stats.ttest_1samp(x,ref).pvalue)
rows=[]
for method,g in D.groupby('method'):
 mu=g.population_mean.iloc[0];r=dict(method=method,**estimate(g['mean']-mu));r['mse_ratio']=g.squared_error.mean()/g.iid_mean_variance.iloc[0];r['coverage']=g.covered.mean();rows.append(r)
S=pd.DataFrame(rows);ps=S.p.to_numpy();ix=np.argsort(ps);adj=np.empty(3);adj[ix]=np.minimum(1,np.maximum.accumulate(ps[ix]*(3-np.arange(3))));S['p_holm']=adj;S.to_csv(P/'followup-summary.csv',index=False)
t=D.pivot(index='rep',columns='method',values='mean');paired=estimate(t.original-t.corrected)
(P/'followup-paired.json').write_text(json.dumps(paired,indent=2));print(S.to_string(index=False));print('Paired original-minus-repaired:',paired)
