from pathlib import Path
import numpy as np,pandas as pd,json
from scipy import stats
P=Path(__file__).resolve().parent;D=pd.read_csv(P/'impact.csv');assert len(D)==36000
assert not D.duplicated(['N','m','pattern','rep','method']).any();assert D.groupby(['N','pattern','method']).size().eq(3000).all()
rng=np.random.default_rng(879124)
def boot(x):
 return np.quantile(x[rng.integers(0,len(x),size=(5000,len(x)))].mean(axis=1),[.025,.975])
def holm(p):
 p=np.array(p);ix=np.argsort(p);a=np.empty(len(p));a[ix]=np.minimum(1,np.maximum.accumulate(p[ix]*(len(p)-np.arange(len(p)))));return a
rows=[]
for key,g in D.groupby(['N','pattern','method']):
 mu=g.population_mean.iloc[0];v=g.iid_mean_variance.iloc[0];err=g['mean'].to_numpy()-mu;mse=g.squared_error.to_numpy();lo,hi=boot(err);ml,mh=boot(mse)/v
 coverage=g.covered.mean();n=len(g);z=stats.norm.ppf(.975);den=1+z*z/n;c=(coverage+z*z/(2*n))/den;h=z*np.sqrt(coverage*(1-coverage)/n+z*z/(4*n*n))/den
 rows.append(dict(zip(['N','pattern','method'],key),mean_bias=err.mean(),mean_sd=err.std(ddof=1),bias_lo=lo,bias_hi=hi,bias_p=stats.ttest_1samp(err,0).pvalue,mse_ratio=mse.mean()/v,mse_ratio_lo=ml,mse_ratio_hi=mh,mse_p=stats.ttest_1samp(mse,v).pvalue,coverage=coverage,coverage_lo=c-h,coverage_hi=c+h,collision_mean=g.collisions.mean(),collision_sd=g.collisions.std(ddof=1)))
S=pd.DataFrame(rows);S['bias_p_holm']=holm(S.bias_p);S['mse_p_holm']=holm(S.mse_p);S.to_csv(P/'impact-summary.csv',index=False)
rows=[]
for key,g in D[D.method!='iid'].groupby(['N','pattern']):
 t=g.pivot(index='rep',columns='method',values='squared_error');v=g.iid_mean_variance.iloc[0];a=(t.original-t.corrected).to_numpy()/v;lo,hi=boot(a)
 rows.append(dict(zip(['N','pattern'],key),original_minus_repaired_mse_over_reference=a.mean(),lo=lo,hi=hi))
pd.DataFrame(rows).to_csv(P/'impact-paired.csv',index=False)
summary={'records':len(D),'fresh_reservoirs':12000,'iid_controls':12000,'mean_tests':12,'mse_tests':12,'mean_rejections':S[S.bias_p_holm<.05][['N','pattern','method']].to_dict('records'),'mse_rejections':S[S.mse_p_holm<.05][['N','pattern','method']].to_dict('records'),'limits':'3000 replicates per cell; absence of rejection is not equivalence; normal coverage is nominal, with known iid variance.'}
(P/'impact-validation.json').write_text(json.dumps(summary,indent=2));print(S[['N','pattern','method','mean_bias','mse_ratio','bias_p_holm','mse_p_holm','coverage']].to_string(index=False))
