# Correctness of the count-factor repair in exact arithmetic

Let $n\geq1$ and $0<p<1$. Write $P_i=\binom ni p^i(1-p)^{n-i}$ and $z=P_0>0$. The normalized cumulative threshold after step $i$ must be $x_i=\sum_{j=0}^iP_j/z$.

The first shortcut threshold is $x_1=1+np/(1-p)$, which equals $(P_0+P_1)/z$. Suppose the recurrence has accumulated the correct normalized mass through step $i-1$. Multiplication by $(n-i+1)p$ in the numerator, by $(1-p)$ in its denominator, and division by $i!$ yields the new normalized mass

$$\frac{n(n-1)\cdots(n-i+1)p^i}{i!(1-p)^i}=\frac{P_i}{P_0}.$$

Induction gives every shortcut threshold exactly. Testing $x_i>t/z$ therefore returns the first count whose cumulative probability exceeds $t$. If the shortcut returns no count by step eight, the unchanged exact-library-quantile specification returns the first cumulative threshold at least $t$. Equality at a threshold has probability zero for a continuous uniform draw. For $n<8$, the threshold reaches one by $i=n$, so later shortcut steps do not affect the law. The ordinary helper handles $t<z$ by returning zero; the positive helper draws $t$ uniformly on $(z,1)$, producing the conditional law given a positive count.

Thus the factor correction recovers the binomial and positive-truncated binomial distributions under exact arithmetic, continuous uniforms and a correct fallback quantile. This proof does not establish the behaviour of finite-bit RNGs, underflow, overflow, cancellation or every implementation of a library quantile. Cases $p=0$ and $p=1$ require separate endpoint handling; conditioning on a positive count at $p=0$ is undefined.

`exact_shortcut.py` independently integrates the source branches as rational intervals. It tests 296 distinct $(n,p)$ pairs, both ordinary and positive-truncated laws. Every repaired distribution equals its analytical reference exactly. The piecewise integration uses $\mathcal O(n+K)$ stored rational values for shortcut depth $K=8$; rational bit costs grow with the denominator and $n$. A conservative bound for constructing all probabilities by separate integer powers is $\mathcal O(n^2)$ arithmetic operations, excluding bit costs. The repair itself changes no asymptotic runtime or storage of the production helper.
