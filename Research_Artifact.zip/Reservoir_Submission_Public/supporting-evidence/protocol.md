# Pilot protocol — frozen before execution, 2026-10-03

Decision sought: whether to undertake an independent replication, not whether a manuscript is ready.

Target: A. Meligrana and A. Fazzone, “Weighted Reservoir Sampling with Replacement from Data Streams,” WWW 2026, pp. 8789–8792, doi:10.1145/3774904.3792966. Algorithm specification: arXiv:2403.20256v7 (16 March 2026). Earlier v5 was initially read; v7 has now been checked. Publisher PDF equivalence remains to be checked before manuscript claims.

Research question: does an independently implemented skip sampler preserve the joint weighted sampling distribution, and under what stream and reservoir settings does its processing advantage persist?

The implementation is written from the mathematical description, without reading the authors' source code. NumPy's random primitives are reused; this is not an independent random-number generator.

Pilot design:
- Algorithms: individual Bernoulli replacement, binomial replacement, skip with positive-truncated binomial replacement.
- Correctness: three streams with weights (1,2,3), (3,2,1), (1,1,1), reservoir size 2; 20,000 independent executions per algorithm/case. Nine Pearson goodness-of-fit tests against the nine-cell ordered-pair distribution. Holm adjustment across nine tests, threshold 0.05. Non-rejection is not proof of correctness.
- Timing feasibility: stream length 10,000, reservoir sizes 10 and 100, weights 1/i, 1, i. Five repetitions of BIN and SKIP, randomized execution order, one warm-up each. Report raw seconds, mean, sample SD, and Student-t 95% CI for mean. These timings do not replicate the published Julia benchmarks and are not an algorithmic speed claim.
- Failures, numerical exceptions and deviations are retained. No optional stopping or seed selection.
- Proceed if the implementation runs, tests expose no unresolved discrepancy, and local timing permits expanded experiments. Acceptance by a journal is outside this criterion.

Full-study requirements still pending: matching the publisher version, independent WRAExp-J baseline, exact experimental units for Add/Get, larger synthetic streams, real-data availability, floating-point boundary tests, seed-level uncertainty, and runtime/RNG/slot-update costs measured separately. Retrieval of a reference and copying a reservoir must be distinguished.
