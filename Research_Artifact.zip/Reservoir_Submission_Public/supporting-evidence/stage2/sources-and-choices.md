# Source and implementation record

Access date: 2026-10-03. No author source code was inspected during implementation.

- Target bibliographic identity: https://doi.org/10.1145/3774904.3792966 — publisher metadata previously verified. Full-text/PDF access attempted in this phase; PDF returned HTTP 403. Do not equate the author manuscript with the version of record without comparison.
- Version used as algorithm specification: https://arxiv.org/html/2403.20256v7 — dated 16 March 2026. Earlier v5 had been read during selection; current work uses v7.
- Comparison mathematical specification: https://doi.org/10.48786/edbt.2023.24 and published PDF at https://wrap.warwick.ac.uk/id/eprint/172076/1/WRAP-Streaming-weighted-sampling-join-queries-22.pdf . Algorithm 2 and Appendix B.3 were inspected; Algorithm 2 page was also rendered locally and visually checked. Its printed power-key ordering conflicts with the explanatory appendix. Use smallest exponential keys (largest power keys) and weight distinct previously emitted items only.
- Earlier weighted-key reference: https://doi.org/10.1016/j.ipl.2005.11.003 . Do not label a without-replacement sample itself as a with-replacement sample.
- ReScience requirements: https://rescience.github.io/write/ . Substantial replication evidence, original code, and reproducibility are required. A negative replication additionally requires an attempt to contact the original authors; no contact was made and no negative-replication submission is claimed.

Implementation choices made here: midpoint uniforms using 52 random bits; libc++ binomial generation; partial-shuffle distinct-slot selection; rejection/inversion positive-binomial helper; exponential-jump heap and CDF-based conversion; materialized-output interface. These are documented choices, not claims that the authors used identical routines. Benchmark instrumentation is active in every method. The plotting package was installed before the retained primary timing run. The initial overlapping run remains archived.

The theoretical expectation correction and ordering observation are audit notes. Neither has been established as novel, unreported, or sufficient for publication. Bibliographic screening previously found no matching independent replication in its limited search; this is not a comprehensive novelty certificate.
