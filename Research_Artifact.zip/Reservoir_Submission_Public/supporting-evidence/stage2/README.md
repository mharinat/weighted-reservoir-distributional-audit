# Stage 2 research artifact

This directory contains historical experimental evidence. Read the current manuscript and supplement in the repository root; superseded drafts and internal review documents are not part of this release.

## Rebuild from the workspace root

A C++17 compiler and Python environment with the pinned analysis dependencies are required. The Python environment in this workspace is `work/research-venv`.

```sh
mkdir -p work/reservoir-stage2
clang++ -std=c++17 -O3 -DNDEBUG outputs/reservoir-replication/stage2/experiment.cpp -o work/reservoir-stage2/experiment
work/reservoir-stage2/experiment edges > outputs/reservoir-replication/stage2/edges.json
work/reservoir-stage2/experiment correctness > outputs/reservoir-replication/stage2/correctness.jsonl
work/reservoir-stage2/experiment longer > outputs/reservoir-replication/stage2/longer-correctness.jsonl
work/reservoir-stage2/experiment timing > outputs/reservoir-replication/stage2/timings.jsonl
work/reservoir-stage2/experiment extension > outputs/reservoir-replication/stage2/scale-extension.jsonl
work/research-venv/bin/python outputs/reservoir-replication/stage2/analyze.py
```

Run timing commands sequentially without other heavy workloads. The commands overwrite generated records: preserve the supplied files first if retaining the original run is important. Probabilistic counts are deterministic only for matching compiler, standard library, source and seeds. Timings vary. The report builder is a record of this observed run, not a general manuscript generator: some conclusions and illustrative paragraphs are fixed and MUST be manually rechecked after rerunning. `analyze.py` recalculates all statistical summaries.

The analysis environment collector currently uses macOS `sysctl`; port that small block when running on another OS. Generated tables include all configurations; figures show the primary timing grid and retrieval comparison. CSV files are plain machine-readable data, not formatted spreadsheet deliverables.

## Integrity and retained deviations

`SHA256SUMS.json` covers source, protocol, analysis outputs and reports in this directory (excluding itself). Source and protocol hashes also appear in environment.json. `timings-initial-overlap.jsonl` is the excluded initial pass that overlapped dependency installation; it is retained for transparency and is not used by analyze.py. The historical `correctness-precheck.json` precedes the expanded analysis and does not replace the raw counts.

## Domain and implementation limitations

Input items have positive finite double weights. Empty streams, invalid reservoir size and invalid weights are rejected; thresholds, keys and cumulative weights must remain representable. The artifact is research code, not a general-purpose numerically hardened library. BERN/BIN/SKIP use distinct stream positions as identities. EXPJ-CDF follows the exponential-race ordering in the EDBT 2023 appendix and is not a literal transcription of its inconsistent Algorithm 2 notation.

The benchmark includes sampler construction and streamed traversal of an in-memory input array. I/O and weight generation are excluded. RNG counters measure engine calls, not conceptual distribution draws. Get materializes output; the comparator uses a heap copy and binary-search CDF instead of the target's dynamic sampler. No universal performance claim or completed real-data replication is made.

No publication license, author list, public repository, or submission has been established yet.
