#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
struct RNG {
 using result_type=uint64_t; std::mt19937_64 engine; uint64_t calls=0;
 explicit RNG(uint64_t seed):engine(seed){}
 static constexpr result_type min(){return std::mt19937_64::min();}
 static constexpr result_type max(){return std::mt19937_64::max();}
 result_type operator()(){++calls;return engine();}
 double u(){return (double((*this)()>>12)+0.5)*0x1p-52;}
};
enum Mode{BERN,BIN,SKIP,EXPJ};
const char* names[]={"BERN","BIN","SKIP","EXPJ-CDF"};
struct Entry {double key,w; int id; bool operator<(const Entry& b)const{return key<b.key;}};
struct Sampler {
 Mode mode; int m,n=0; RNG rng; double W=0,threshold=0,jump=0;
 uint64_t events=0,replacements=0;
 std::vector<int> reservoir,perm;
 std::priority_queue<Entry> heap;
 Sampler(Mode mode,int m,uint64_t seed):mode(mode),m(m),rng(seed){
  if(m<=0)throw std::invalid_argument("m must be positive");
  if(mode!=EXPJ){reservoir.resize(m);perm.resize(m);std::iota(perm.begin(),perm.end(),0);}
 }
 double finite_positive(double x){if(!(x>0)||!std::isfinite(x))throw std::overflow_error("unrepresentable key/threshold");return x;}
 void reset_threshold(){threshold=finite_positive(W/std::exp(std::log(rng.u())/m));}
 void reset_jump(){jump=finite_positive(-std::log(rng.u())/heap.top().key);}
 int positive_binomial(double p){
  if(p>=1)return m;
  double a=-std::expm1(m*std::log1p(-p));
  if(!(a>0))throw std::underflow_error("conditional mass underflow");
  if(a>.25){std::binomial_distribution<int>d(m,p);int k;do{k=d(rng);}while(!k);return k;}
  double mass=m*p*std::exp((m-1)*std::log1p(-p))/a,u=rng.u(),sum=mass;int k=1;
  while(u>sum&&k<m){mass*=double(m-k)/(k+1)*p/(1-p);++k;sum+=mass;}return k;
 }
 void replace(int k,int id){
  if(k){++events;replacements+=k;}
  for(int j=0;j<k;++j){int q=std::uniform_int_distribution<int>(j,m-1)(rng);std::swap(perm[j],perm[q]);reservoir[perm[j]]=id;}
 }
 void add(double w){
  if(!(w>0)||!std::isfinite(w))throw std::invalid_argument("weight must be finite positive");
  W+=w;if(!std::isfinite(W))throw std::overflow_error("cumulative weight overflow");
  int id=n++;
  if(mode==EXPJ){
   if(int(heap.size())<m){heap.push({finite_positive(-std::log(rng.u())/w),w,id});if(int(heap.size())==m)reset_jump();}
   else if((jump-=w)<=0){
    double T=heap.top().key;
    double key=finite_positive(-std::log1p(-rng.u()*(-std::expm1(-w*T)))/w);
    heap.pop();heap.push({key,w,id});++events;++replacements;reset_jump();
   }return;
  }
  if(id==0){if(mode==SKIP)reset_threshold();return;}
  double p=w/W;
  if(mode==BERN){int k=0;for(auto& x:reservoir)if(rng.u()<p){x=id;++k;}if(k){++events;replacements+=k;}}
  else if(mode==BIN)replace(std::binomial_distribution<int>(m,p)(rng),id);
  else if(W>=threshold){reset_threshold();replace(positive_binomial(p),id);}
 }
 std::vector<int> get(){
  if(!n)throw std::invalid_argument("empty stream");
  if(mode!=EXPJ)return reservoir;
  auto copy=heap;std::vector<Entry> ordered;ordered.reserve(copy.size());
  while(!copy.empty()){ordered.push_back(copy.top());copy.pop();}std::reverse(ordered.begin(),ordered.end());
  std::vector<double> cdf;cdf.reserve(ordered.size());double seen=0;size_t used=0;
  std::vector<int> result;result.reserve(m);
  for(int j=0;j<m;++j){double u=rng.u()*W;
   if(u<seen){auto index=std::upper_bound(cdf.begin(),cdf.end(),u)-cdf.begin();result.push_back(ordered[index].id);}
   else {if(used>=ordered.size())throw std::runtime_error("exhausted ordered reservoir");seen+=ordered[used].w;cdf.push_back(seen);result.push_back(ordered[used++].id);}
  }return result;
 }
};
using Clock=std::chrono::steady_clock;
double elapsed(Clock::time_point t){return std::chrono::duration<double>(Clock::now()-t).count();}
void correctness(int reps){
 std::array<std::array<double,3>,5> cases={{{1,2,3},{3,2,1},{1,1,1},{1e-200,2e-200,3e-200},{1e200,2e200,3e200}}};
 for(int c=0;c<5;++c)for(int m=1;m<=3;++m)for(int a=0;a<4;++a){
  int cells=int(std::pow(3,m));std::vector<int> counts(cells);
  RNG seeds(719000+c*100+m*10+a);
  for(int r=0;r<reps;++r){Sampler s(Mode(a),m,seeds());for(double w:cases[c])s.add(w);auto v=s.get();int code=0;for(int x:v)code=3*code+x;++counts.at(code);}
  std::cout<<"{\"case\":"<<c<<",\"m\":"<<m<<",\"algorithm\":\""<<names[a]<<"\",\"reps\":"<<reps<<",\"counts\":[";
  for(int i=0;i<cells;++i)std::cout<<(i?",":"")<<counts[i];std::cout<<"]}\n";
 }
}
void edges(){
 int passed=0;
 for(int a=0;a<4;++a){
  auto expect=[&](auto f){bool threw=false;try{f();}catch(const std::exception&){threw=true;}if(!threw)throw std::runtime_error("missing validation");++passed;};
  expect([&]{Sampler s(Mode(a),0,1);});expect([&]{Sampler s(Mode(a),2,1);s.get();});
  for(double w:{0.,-1.,std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN()})expect([&]{Sampler s(Mode(a),2,1);s.add(w);});
  expect([&]{Sampler s(Mode(a),2,1);s.add(1e308);s.add(1e308);});
  Sampler s(Mode(a),3,8);s.add(1);auto v=s.get();if(v!=std::vector<int>(3,0))throw std::runtime_error("singleton failed");++passed;
 }
 std::cout<<"{\"edge_checks_passed\":"<<passed<<"}\n";
}
volatile uint64_t sink=0;
void timing(bool extension){
 RNG order(93012026);std::vector<int> ns=extension?std::vector<int>{10000000}:std::vector<int>{100000,1000000};int reps=extension?5:20;
 for(int N:ns)for(int pattern=0;pattern<3;++pattern){
  std::vector<double> weights(N);for(int i=0;i<N;++i)weights[i]=pattern==0?1./(i+1):pattern==1?1.:i+1.;
  std::vector<int> ms=extension?std::vector<int>{1000,10000}:std::vector<int>{N/10000,N/1000,N/100,N/10};
  for(int m:ms){
   for(int a=1;a<4;++a){Sampler s(Mode(a),m,123);for(double w:weights)s.add(w);auto v=s.get();sink+=v.back();}
   for(int rep=0;rep<reps;++rep){std::array<int,3> algs={1,2,3};std::shuffle(algs.begin(),algs.end(),order);
    for(int a:algs){uint64_t seed=100000+rep;auto start=Clock::now();Sampler s(Mode(a),m,seed);for(double w:weights)s.add(w);double add=elapsed(start);uint64_t add_rng=s.rng.calls;
     start=Clock::now();auto v=s.get();double get=elapsed(start);uint64_t checksum=0;for(int x:v)checksum+=x;sink+=checksum;
     std::cout<<std::setprecision(17)<<"{\"N\":"<<N<<",\"m\":"<<m<<",\"pattern\":"<<pattern<<",\"rep\":"<<rep<<",\"seed\":"<<seed<<",\"algorithm\":\""<<names[a]<<"\",\"add_seconds\":"<<add<<",\"get_seconds\":"<<get<<",\"rng_add\":"<<add_rng<<",\"rng_get\":"<<s.rng.calls-add_rng<<",\"events\":"<<s.events<<",\"replacements\":"<<s.replacements<<",\"checksum\":"<<checksum<<"}\n";
    }
   }std::cerr<<"completed N="<<N<<" pattern="<<pattern<<" m="<<m<<"\n";
  }
 }
}
void longer(){
 for(int N:{33,257})for(int pattern=0;pattern<3;++pattern)for(int a=0;a<4;++a){
  std::vector<double> weights(N);std::array<double,3> mass={0,0,0};double total=0;
  for(int i=0;i<N;++i){double w=pattern==0?1./(i+1):pattern==1?1.:i+1.;weights[i]=w;mass[i%3]+=w;total+=w;}
  std::array<int,9>counts={};RNG seeds(38100+N*100+pattern*10+a);
  for(int r=0;r<20000;++r){Sampler sampler(Mode(a),2,seeds());for(double w:weights)sampler.add(w);auto v=sampler.get();++counts[(v[0]%3)*3+v[1]%3];}
  std::cout<<std::setprecision(17)<<"{\"N\":"<<N<<",\"pattern\":"<<pattern<<",\"algorithm\":\""<<names[a]<<"\",\"reps\":20000,\"probabilities\":["<<mass[0]/total<<","<<mass[1]/total<<","<<mass[2]/total<<"],\"counts\":[";
  for(int i=0;i<9;++i)std::cout<<(i?",":"")<<counts[i];std::cout<<"]}\n";
 }
}
int main(int argc,char**argv){try{std::string task=argc>1?argv[1]:"edges";if(task=="correctness")correctness(argc>2?std::stoi(argv[2]):100000);else if(task=="edges")edges();else if(task=="timing")timing(false);else if(task=="extension")timing(true);else if(task=="longer")longer();else throw std::invalid_argument("unknown task");}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
