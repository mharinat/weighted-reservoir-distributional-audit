"""Rebuild statistical summaries and figures from retained raw records."""
import hashlib,itertools,json,math,platform,subprocess
from pathlib import Path
import numpy as np,pandas as pd,scipy
from scipy.stats import chisquare,t,ttest_1samp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent

def records(name):return [json.loads(x) for x in (P/name).read_text().splitlines() if x.strip()]
def holm(rows,key='p',target='p_holm'):
 last=0
 for j,row in enumerate(sorted(rows,key=lambda r:r[key])):
  last=max(last,min(1,(len(rows)-j)*row[key]));row[target]=last

def correctness(name,long=False):
 rows=records(name)
 for x in rows:
  if long:probs=np.array(x['probabilities']);m=2
  else:
   probs=np.array([1,2,3] if x['case'] in [0,3,4] else [3,2,1] if x['case']==1 else [1,1,1],float);probs/=sum(probs);m=x['m']
  expected=probs
  for _ in range(m-1):expected=np.outer(expected,probs).ravel()
  observed=np.array(x['counts']);stat,pvalue=chisquare(observed,expected*x['reps'])
  x.update(chi2=float(stat),p=float(pvalue),tv=float(.5*np.abs(observed/x['reps']-expected).sum()),minimum_expected_count=float(min(expected*x['reps'])))
  # Union bound over all subsets and all tests, from Hoeffding's inequality.
  x['tv_upper_simultaneous95']=min(1,x['tv']+math.sqrt((len(expected)*math.log(2)+math.log(len(rows)/.05))/(2*x['reps'])))
 holm(rows);return rows

def timing(name):
 df=pd.DataFrame(records(name));summ=[]
 for keys,g in df.groupby(['N','m','pattern','algorithm']):
  row=dict(zip(['N','m','pattern','algorithm'],keys));row['repetitions']=len(g)
  for field in ['add_seconds','get_seconds','rng_add','rng_get','events','replacements']:
   a=g[field].to_numpy();mean=float(a.mean());sd=float(a.std(ddof=1));half=float(t.ppf(.975,len(a)-1)*sd/math.sqrt(len(a)))
   row.update({field+'_mean':mean,field+'_sd':sd,field+'_ci_low':mean-half,field+'_ci_high':mean+half})
  summ.append(row)
 contrasts=[]
 for keys,g in df.groupby(['N','m','pattern']):
  pivot=g.pivot(index='rep',columns='algorithm',values='add_seconds')
  for base in ['BIN','EXPJ-CDF']:
   d=np.log(pivot['SKIP']/pivot[base]).to_numpy();mu=float(d.mean());se=float(d.std(ddof=1)/math.sqrt(len(d)));half=float(t.ppf(.975,len(d)-1)*se)
   row=dict(zip(['N','m','pattern'],map(int,keys)));row.update(baseline=base,ratio=math.exp(mu),ci_low=math.exp(mu-half),ci_high=math.exp(mu+half),p=float(ttest_1samp(d,0).pvalue));contrasts.append(row)
 holm(contrasts);return pd.DataFrame(summ),contrasts

def main():
 primary=correctness('correctness.jsonl');longer=correctness('longer-correctness.jsonl',True)
 summaries,contrasts=timing('timings.jsonl');extension,_=timing('scale-extension.jsonl')
 summaries.to_csv(P/'timing-summary.csv',index=False);pd.DataFrame(contrasts).to_csv(P/'runtime-contrasts.csv',index=False);extension.to_csv(P/'extension-summary.csv',index=False)
 rng=np.random.default_rng(452);counts=np.zeros(9,dtype=int);single=rng.choice(3,100000,p=[1/6,2/6,3/6]);np.add.at(counts,single*4,1)
 stat,pvalue=chisquare(counts,np.outer([1/6,2/6,3/6],[1/6,2/6,3/6]).ravel()*100000)
 result={'correctness_primary':primary,'correctness_longer':longer,'contrasts':contrasts,'negative_control':{'description':'Repeated identical item in both slots; correct marginals but wrong joint law','counts':counts.tolist(),'chi2':float(stat),'p':float(pvalue)},'totals':{'primary_reservoirs':sum(x['reps'] for x in primary),'longer_reservoirs':sum(x['reps'] for x in longer),'timing_records':len(records('timings.jsonl')),'extension_records':len(records('scale-extension.jsonl')),'zero_get_readings':sum(x['get_seconds']==0 for x in records('timings.jsonl'))}}
 (P/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False))
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(2,3,figsize=(13,7),sharex=True)
 patterns=['Decreasing weights','Constant weights','Increasing weights']
 colors={'BIN':'#486581','SKIP':'#c44e52','EXPJ-CDF':'#2a9d8f'}
 for row,N in enumerate([100000,1000000]):
  for col in range(3):
   ax=axes[row,col]
   for alg in colors:
    s=summaries[(summaries.N==N)&(summaries.pattern==col)&(summaries.algorithm==alg)].sort_values('m')
    ax.errorbar(s.m/N,s.add_seconds_mean*1000,yerr=(s.add_seconds_ci_high-s.add_seconds_mean)*1000,label=alg,color=colors[alg],marker='o',capsize=3)
   ax.set_xscale('log');ax.set_yscale('log');ax.set_title(f'{patterns[col]} | N={N:,}');ax.set_xlabel('Reservoir fraction m/N');ax.set_ylabel('Processing time (ms)')
 axes[0,0].legend();fig.suptitle('Independent C++ implementations: processing time, mean and 95% CI',fontsize=14)
 fig.tight_layout();fig.savefig(P/'processing-time.png',dpi=180);fig.savefig(P/'processing-time.svg');plt.close(fig)
 fig,axes=plt.subplots(1,3,figsize=(13,3.8))
 for col,ax in enumerate(axes):
  for alg in colors:
   s=summaries[(summaries.N==1000000)&(summaries.pattern==col)&(summaries.algorithm==alg)].sort_values('m')
   ax.plot(s.m,s.get_seconds_mean*1e6,marker='o',label=alg,color=colors[alg])
  ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('Reservoir size m');ax.set_ylabel('Materialized retrieval (microseconds)');ax.set_title(patterns[col])
 axes[0].legend();fig.suptitle('Retrieval implementations differ; EXPJ-CDF is not the optimized published baseline',fontsize=12);fig.tight_layout();fig.savefig(P/'retrieval-time.png',dpi=180);plt.close(fig)
 env={'python':platform.python_version(),'os':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__,'compiler':subprocess.check_output(['clang++','--version'],text=True),'flags':'-std=c++17 -O3 -DNDEBUG; no fast-math','cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'ram_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'rng':'std::mt19937_64; midpoint uniforms from 52 random bits','source_sha256':hashlib.sha256((P/'experiment.cpp').read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((P.parent/'stage2-protocol.md').read_bytes()).hexdigest()}
 (P/'environment.json').write_text(json.dumps(env,indent=2))
 print(json.dumps({'totals':result['totals'],'primary_min_p_holm':min(x['p_holm'] for x in primary),'longer_min_p_holm':min(x['p_holm'] for x in longer),'max_tv_upper':max(x['tv_upper_simultaneous95'] for x in primary),'ratio_ranges':{base:[min(x['ratio'] for x in contrasts if x['baseline']==base),max(x['ratio'] for x in contrasts if x['baseline']==base)] for base in ['BIN','EXPJ-CDF']},'significantly_slower':[x for x in contrasts if x['ratio']>1 and x['p_holm']<.05]},indent=2))
if __name__=='__main__':main()
