# Stage 2 protocol — 2026-10-03, before new experiments

This is an extension of the feasibility pilot, not a retrospective replacement. Primary target remains arXiv:2403.20256v7 / WWW 2026 DOI 10.1145/3774904.3792966. Publisher full text returned HTTP 403; equivalence to the version of record is unverified.

## Independent implementations

C++17, one compiler and RNG family for all methods. Implement Bernoulli (correctness only), binomial, skip, and an exponential-jump reservoir followed by with-replacement conversion. The latter follows the exponential-race interpretation in Appendix B.3 of Shekelyan et al., DOI 10.48786/edbt.2023.24. Use minimum exponential keys, equivalent to maximum power keys; the ordering printed in Algorithm 2 conflicts with its explanatory appendix. Follow the appendix and record this interpretation. No author source code has been read.

The conversion uses sorting and prefix-weight binary search, NOT the dynamic sampler used in the target paper. Label it EXPJ-CDF. Its retrieval performance cannot reproduce the target's optimized WRAExp-J retrieval claim. Processing comparisons are informative for this implementation, not identical implementations of the authors' benchmarks.

## Correctness

100,000 independent replications per cell, four algorithms, sample sizes 1, 2, 3 and five weight vectors: (1,2,3), (3,2,1), (1,1,1), (1,2,3)*1e-200, (1,2,3)*1e200. Total 60 tests / 6 million reservoirs. Compare ordered tuples to the product categorical law with Pearson goodness-of-fit; all expected cell counts exceed 5. Holm correction over all 60 tests; alpha 0.05. Report total variation distance and simultaneous Hoeffding-based upper bounds; lack of rejection is not equivalence.

Edge cases: empty stream, invalid reservoir size, nonpositive/nonfinite weights and overflowing cumulative weight must throw; N=1 must return copies of item 0. The supported numeric domain additionally requires representable thresholds/exponential keys; extreme finite inputs outside it may throw. All failures retained. Run address/undefined-behaviour sanitizer checks on a reduced correctness suite before release-mode experiments.

## Timing

N=100,000 and 1,000,000; m/N in {0.0001,0.001,0.01,0.1}; weights 1/i,1,i; 20 replications per configuration, BIN/SKIP/EXPJ-CDF, randomized order inside each repetition. One warmup per cell. Precomputed weights shared by all methods; input loading excluded. Add includes sampler construction and traversal; Get includes a materialized sample for every method. RNG instrumentation counts underlying engine calls; these are not abstract variates. Also count accepted updates and replacements. Correctness suite must be evaluated before timing claims.

Report mean, sample SD and t-based 95% CI, plus paired log runtime ratios SKIP/BIN and SKIP/EXPJ-CDF with confidence intervals and Holm-adjusted paired t-tests (48 contrasts). Check tails and discuss machine-state/normality limitations. Full raw records retained. Do not select only favourable configurations. Allocation, compiler, machine and library choices are threats to external validity.

If these runs are inexpensive, add a separately labelled scale extension at N=10,000,000 with 5 repetitions, m in {1000,10000}, all three weight patterns. No inferential pooling with primary tests.

## Deliverables and limits

Code, raw measurements, analysis, figures, and a working manuscript with measured results. No invented real-data results or public submission. Real-data evaluation, matching publisher text, and optimized dynamic-sampler parity remain submission gates.

## Recorded execution adjustment / additional checks

The first timing pass overlapped installation of plotting dependencies. Retain it as `timings-initial-overlap.jsonl` and exclude it from primary inference. Repeat the predeclared timing design once after dependency installation has completed; no timing results were selected by favourability.

After evaluating the initial 60 correctness tests (none rejected), add a separate family of 24 longer-stream checks: N in {33,257}, weights 1/i,1,i, m=2, four algorithms, 20,000 independent reservoirs per cell. Map item ids modulo 3, compare the nine ordered-pair categories to their exact aggregated weight probabilities, and apply Holm within this separate family. This is a documented extension, not part of the original 60-test family. A deliberately correlated negative control demonstrates why marginal-frequency checks alone are insufficient.

## Post-run measurement limitation

Artifact validation found 16 zero-duration single Get readings in the primary grid, all retained. These are below the timer's observable resolution, not zero-cost retrieval. All Add readings are positive and the declared processing contrasts are unaffected. Retrieval plots remain descriptive; batched retrieval timing is a remaining measurement gate before retrieval claims. No zero was replaced by an arbitrary epsilon.
