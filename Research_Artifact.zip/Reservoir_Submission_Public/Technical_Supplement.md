# Technical supplement

Companion to Research_Manuscript.md, version 11. References [1]–[15] use the main manuscript bibliography. Methods, proofs and diagnostic results accompany the main paper. This editorial revision preserves the recorded numerical results; no new samples were generated.

## S1. Artifact provenance

The originally inspected commit is `408dd06f8ea9e60b412e27a73f0f277bb590cb84`. A paginated GitHub API query for the default-branch history of `comparison/samplers.jl` returned one path commit, `686fa7aba586bbd02a7d9b1173eed245bf12f089` (17 November 2025), whose file status is “added.” At retrieval, default HEAD was `c6c3dea92cd8385c5576dc5905391b10883b2ca8` (29 June 2026). The three file contents are byte-identical, SHA256 `b9478d4659fc37fe5160d022b54b72f1fbf19bbdf8a1f6f0e9693cfd44f3912a`. Byte identity extends the findings to the file at the retrieved HEAD; the identical copies were not rerun separately. This path history does not cover renamed predecessors, every branch, or the exact unpublished environment used for the figures. The released StreamSampling package remains outside the claim scope.

## S2. Experimental methods

### Provenance and phases

Stage 2 contains the original independent C++ code and its saved hashes. Its correctness and timing experiments are retained as a separate development record; Supplement S11 gives their scope. Stage 3 began only after that implementation was frozen. Stage-3 diagnostics and repairs used the inspected source.

The native audit uses Julia 1.12.1, a SHA256-verified official archive, and the unmodified pinned `comparison/samplers.jl`. The validation environment contains DataStructures 0.19.6, Distributions 0.25.131, StatsBase 0.34.13, and WeightVectors 0.1.1. Its complete Project and Manifest files are supplied. Historical equality to the authors' dependency environment is not established.

### Exact distributions

For unit weights and $m=4$, the occupancy partition records multiplicities while discarding label identities. Fixing the exponential-key rank order does not change this partition law. The initial diagnostic enumerates 64 equally likely conversion paths and compares them with 256 iid four-label paths. A weighted-path extension uses rational arithmetic to evaluate 18 combinations of $m\in\{2,3,4,5,6,8\}$ and $N\in\{m,10m,100m\}$.

For an occupancy partition $\lambda=(\lambda_1,\ldots,\lambda_k)$ of $m$ and $N$ equiprobable labels, the reference probability is

$$P_0(\lambda)=\frac{(N)_k\,m!}{N^m\prod_i\lambda_i!\prod_{r\geq1}b_r!},$$

where $(N)_k=N(N-1)\cdots(N-k+1)$ and $b_r$ is the number of parts equal to $r$. This analytical reference does not depend on a sampling implementation.

### Native experiments and inference

The initial conversion experiment generates one million samples per unchanged, repaired and iid-control method at $N=m=4$. The first extension repeats the occupancy experiment at $N=40,m=4$, again with one million samples per method. For these equal-weight occupancy tests only, a fixed prebuilt reservoir can be reused: label order does not affect the statistic's distribution, and each query uses fresh pseudorandom draws. For general weighted statistics, repeated queries condition on the fixed reservoir and do not recover the unconditional sampling law.

A weighted extension uses weights $(1,2,3,4)$, $N=m=4$, and 100,000 newly constructed reservoirs per method. All 35 count vectors are compared with the multinomial reference. Minimum expected counts are ten. Pearson tests use Holm adjustment [11] and are corrected across the three initial tests and, separately, across the six follow-up tests.

At $N=10{,}000,m=1{,}000$, 10,000 samples per method measure the number of equal-label pairs

$$Q=\sum_{a<b}\mathbf1\{X_a=X_b\}.$$

Under iid uniform sampling, $\mathbb E[Q]=\binom m2/N$ and $\operatorname{Var}(Q)=\binom m2(1/N)(1-1/N)$. Overlapping pair indicators are uncorrelated in this uniform case. Sample means, sample SDs, Student-$t$ intervals and Holm-adjusted one-sample tests are reported for this separate three-test family.

A further diagnostic tests the original BERN/BIN/SKIP comparison routines: $m=4$, unit-weight streams of length 8 and 40, and the four-item weighted stream. There are 200,000 freshly constructed reservoirs per cell. The longer streams are mapped into four equal-weight label classes; their count vector remains multinomial. The nine tests are corrected together. A separate nine-test family evaluates a one-factor count-helper repair with the same seeds. These diagnostic extensions were selected after inspection of the initial failures; they are not presented as preregistered generalization experiments.

## S3. Conversion defect

The unchanged conversion introduces weight categories according to the output position while advancing its next-unseen-item pointer only on one selection branch. A previously un-emitted rank can therefore be returned without advancing that pointer. A subsequent selection can reuse the same rank where a new rank was required.

For $m=4$, $N\geq4$, and unit weights, direct enumeration gives an excess

$$\delta_N=\frac{N-3}{N^3}$$

in partition $(2,2)$ and an equal deficit in $(2,1,1)$. Other occupancy probabilities are unchanged. One discrepant path first repeats the initial rank, then emits the second rank through the preintroduced category, then selects the remaining-mass category. The first two choices each have probability $1/N$, and the last has probability $(N-3)/N$. In the unchanged routine the next-unseen pointer still identifies the second rank. The repaired construction advances the distinct-item state and instead produces a new rank. Since partition identities ignore rank labels, the discrepancy is not an artefact of sorting the output.

For $N=4$, the complete exact distribution is:

| Partition | IID law | Unchanged conversion | Repaired conversion |
|---|---:|---:|---:|
| $(4)$ | $1/64$ | $1/64$ | $1/64$ |
| $(3,1)$ | $3/16$ | $3/16$ | $3/16$ |
| $(2,2)$ | $9/64$ | $10/64$ | $9/64$ |
| $(2,1,1)$ | $36/64$ | $35/64$ | $36/64$ |
| $(1,1,1,1)$ | $3/32$ | $3/32$ | $3/32$ |

The total variation distance on these partitions is $1/64$. The exact discrepancy establishes failure of the required occupancy law in this case. Native execution checks whether the transcription reproduces the program's behaviour.

Native execution produced 0.156210 for partition $(2,2)$, with Wilson [12] 95% CI [0.155500, 0.156923]. The iid occupancy law is rejected for the unchanged program ($p<10^{-300}$), but is consistent with the exact program-specific law ($p=0.1592$). The repaired conversion produced 0.140519, with 95% CI [0.139839, 0.141202], and its raw goodness-of-fit p-value was 0.8367. The repaired sample does not reject the reference law; its mathematical justification rests on the argument below.

![Native counterexample](supporting-evidence/stage3/native-counterexample.png)

Supplementary figure. One million native samples per method. Error bars are Wilson 95% intervals for the two-pair event.

| Follow-up case | Method | Pearson statistic | Raw p | Holm-adjusted p |
|---|---|---:|---:|---:|
| N=40, m=4, uniform | original | 244.841 | 8.4127e-52 | 5.0476e-51 |
| N=40, m=4, uniform | corrected | 5.957 | 0.20237 | 0.80949 |
| N=40, m=4, uniform | iid | 1.514 | 0.82412 | 0.82412 |
| N=m=4, weights 1:4 | original | 205.279 | 2.2768e-26 | 1.1384e-25 |
| N=m=4, weights 1:4 | corrected | 39.056 | 0.25299 | 0.80949 |
| N=m=4, weights 1:4 | iid | 40.381 | 0.20902 | 0.80949 |

At $N=10{,}000,m=1{,}000$, the theoretical mean collision count is 49.95:

| Method | Mean | Sample SD | 95% CI for mean | Holm-adjusted p |
|---|---:|---:|---|---:|
| original | 51.5158 | 7.4194 | [51.3704, 51.6612] | 2.7553e-96 |
| corrected | 49.8851 | 7.0909 | [49.7461, 50.0241] | 0.72016 |
| iid | 49.9499 | 7.0427 | [49.8118, 50.0880] | 0.99887 |

The larger diagnostic shows that the defect persists at a 10% reservoir fraction beyond a four-draw example. It does not quantify the effect at the original paper's full stream sizes or on its real dataset.

At $N=40,m=4$, a post-audit diagnostic against the exact source-specific occupancy law gives $\chi^2_4=6.3736$ and unadjusted $p=0.1729$. This selected, unadjusted check is descriptive; failure to reject does not establish equality of laws. The four-output failure path does not occur for $m<4$; this statement concerns conversion, not the separate count helper.

## S4. Justification of the conceptual conversion repair

Assume $N\geq m\geq1$, strictly positive finite weights $w_i$, total $W=\sum_iw_i$, exact arithmetic, and an ordered reservoir containing the first $m$ elements of a size-biased random permutation $R$. Its conditional rank law is

$$\Pr(R_{k+1}=i\mid R_1,\ldots,R_k)=\frac{w_i}{W-\sum_{j=1}^{k}w_{R_j}}$$

for every not-yet-revealed label $i$. Independent exponential keys with rates $w_i$, sorted in ascending order, have this law: the minimum has probability $w_i/W$, and memorylessness gives the same argument after each removal. Distinct tie-free keys and correctly retained top ranks are assumptions; this statement does not verify all floating-point reservoir implementations.

The repaired conversion emits $R_1$ first. After $t$ outputs, let $U_t$ be the set of distinct emitted items and $k=|U_t|$. Its invariant is $U_t=\{R_1,\ldots,R_k\}$. The dynamic sampler holds weight $w_i$ for each $i\in U_t$ and one residual category with weight $W-\sum_{i\in U_t}w_i$. A repeat leaves $k$ unchanged. A residual draw emits $R_{k+1}$ and increments $k$; the newly exposed item's weight is transferred from the residual category to its own category.

Condition on the output history. Its repeat and residual decisions depend only on the revealed prefix and fresh auxiliary draws; they reveal no extra information about the order of the unseen suffix. A seen item has next-output probability $w_i/W$. An unseen item has probability

$$\frac{W-\sum_{j\in U_t}w_j}{W}\cdot\frac{w_i}{W-\sum_{j\in U_t}w_j}=\frac{w_i}{W}.$$

Therefore each next conditional law equals the target weighted law. Induction gives

$$\Pr(X_1=x_1,\ldots,X_m=x_m)=\prod_{t=1}^{m}\frac{w_{x_t}}W.$$

At most $m$ ranks are needed because there are only $m$ outputs. This establishes the conceptual converter's law under the stated assumptions. Its count vector consequently has the required multinomial distribution. Reusing one fixed weighted reservoir for arbitrary sample-mean inference does not meet the unconditional rank assumption; the impact experiments rebuild each reservoir.

The original position-based category activation breaks the invariant: a rank can become selectable before it advances the distinct-rank pointer. The local repair makes category activation follow $k$, not $t$.

An additional exact check integrates all size-biased key permutations for 19 small cases with uniform, increasing, decreasing and highly unequal positive integer weights, $N\leq5$, and $m\leq N$. Every repaired ordered-output probability equals the iid product law as a rational number; five original cases differ. This model check assumes the rank-order law and uses a source-informed transcription; it adds no native executions. Its source, full parameter list and exact discrepancies are supplied in `exact_weighted_conversion.py` and `exact-weighted-results.json`.

## S5. Shared count-shortcut defect

Let $P_i=\Pr(B=i)$ for $B\sim\operatorname{Bin}(m,p)$. The recurrence is

$$\frac{P_i}{P_{i-1}}=\frac{m-i+1}{i}\frac{p}{1-p}.$$

The inspected shortcut instead uses a factor $m-i$ in its fast cumulative calculation. It falls back to a library quantile outside the shortcut region, so the resulting distribution cannot be inferred by simply renormalizing the wrong recurrence. Exact integration over its branching intervals is required.

At $m=4,p=1/4$, that integration gives:

| Replacement count | Binomial law | Shortcut law |
|---|---:|---:|
| 0 | $81/256$ | $81/256$ |
| 1 | $27/64$ | $27/64$ |
| 2 | $27/128$ | $25/128$ |
| 3 | $3/64$ | $1/16$ |
| 4 | $1/256$ | $1/256$ |

Probability $1/64$ is transferred from two replacements to three. The positive-truncated helper uses the same shortcut and inherits the discrepancy after conditioning. A local copy changes only the recurrence factor to $m-i+1$; the original file remains byte-identical.

| Diagnostic cell | Original Holm-adjusted p | Count-factor repair Holm-adjusted p |
|---|---:|---:|
| unit8 / BERN | 1 | 1 |
| unit8 / BIN | 5.2198e-81 | 1 |
| unit8 / SKIP | 1.5594e-06 | 1 |
| unit40 / BERN | 1 | 1 |
| unit40 / BIN | 1 | 1 |
| unit40 / SKIP | 0.76375 | 1 |
| weighted4 / BERN | 1 | 1 |
| weighted4 / BIN | <1e-300 | 1 |
| weighted4 / SKIP | 1 | 1 |

The single-factor intervention removes the three rejections in the original nine-cell family. The BERN control does not use this helper. Rejections occur in two of three BIN cases and one of three SKIP cases. The other tests do not establish exactness: their finite sample sizes limit detection of smaller discrepancies. The repair does not address all possible floating-point underflow or overflow cases.

Source inspection establishes that the original Add experiment excludes construction and reports nanoseconds per input item. SKIP initialization also differs from our initial implementation, and the comparison Get explicitly sorts heap entries before dynamic sampling. Earlier C++ ranking reversals therefore cannot be interpreted as a controlled refutation of the original performance results. The native experiment below matches construction boundaries and applies the validated repairs. Historical dependency equality remains unestablished, so it is still not an exact reproduction of the published figures.

## S6. Count-repair proof and large-count checks

Let $P_i=\binom ni p^i(1-p)^{n-i}$, $z=P_0$, $n\geq1$, and $0<p<1$. The shortcut starts with $x_1=1+np/(1-p)=(P_0+P_1)/z$. With the repaired factor, step $i$ adds

$$\frac{n(n-1)\cdots(n-i+1)p^i}{i!(1-p)^i}=P_i/z.$$

Induction gives $x_i=\sum_{j=0}^iP_j/z$, so comparing $x_i$ to $t/z$ performs inverse-CDF sampling; a correct fallback quantile covers the remaining interval. Restricting the uniform draw to $(z,1)$ gives the positive-truncated law. Threshold equality has measure zero under continuous uniforms. This proof assumes exact arithmetic and a correct fallback; it does not settle finite-bit endpoint handling or floating-point errors.

Exact rational integration checks 296 distinct pairs: $n=1,\ldots,50$, five rational probabilities, and $p=1/n$ where distinct and defined. All repaired ordinary and truncated laws match exactly. The executable interval integration and proof are supplied separately. At $n=1000$, 200,000 native draws per cell test five probabilities, both helper types and both versions (20 mean tests). The original ordinary and truncated means at $p=0.004$ reject their references after Holm correction; repaired means do not. These native checks assess execution at larger counts.

| Helper, $n=1000,p=0.004$ | Mean | SD | 95% CI | Reference mean | Holm $p$ |
|---|---:|---:|---|---:|---:|
| original, ordinary | 4.014635 | 2.005096 | [4.005847, 4.023423] | 4.000000 | 0.02086 |
| original, positive | 4.088720 | 1.946671 | [4.080188, 4.097252] | 4.074022 | 0.01468 |
| repaired, ordinary | 4.006250 | 1.996422 | [3.997500, 4.015000] | 4.000000 | 1 |
| repaired, positive | 4.080100 | 1.937837 | [4.071607, 4.088593] | 4.074022 | 1 |

The tested $p=0.9$ cases exercise zero-underflow of $P_0$ and returned finite sample moments; this is not a proof of safety for all extreme inputs. Additional boundary execution confirms a `weigths` field-name exception in SKIP Get when $N<m$, in both original and count-repaired copies. It is a separate, unrepaired interface defect. Valid output shape for a $10^{12}$ weight ratio does not verify its distribution. A zero-leading-weight case is exploratory because the paper assumes strictly positive weights. Partial-heap EXPJ retrieval was not executed because its unchecked indexing presumes a full reservoir.

## S7. Empirical consequence for an estimated mean

The primary extension uses $N\in\{10000,100000\}$, $m=1000$, uniform and increasing weights, and 3,000 fresh reservoirs per configuration. Original and repaired conversion query each built reservoir with separately seeded RNG states; an iid categorical control uses the full population. The two conversions therefore share reservoir randomness. Seeds repeat across configurations, inducing cross-configuration dependence, but no estimates are pooled across configurations and Holm adjustment does not require independence.

For normalized labels $y_i=i/N$ and $p_i=w_i/\sum_jw_j$, the reference is $\mu=\sum_i p_i y_i$, $v=\sum_i p_i(y_i-\mu)^2/m$. Each replicate records $\hat\mu$, $(\hat\mu-\mu)^2$, collisions, and coverage of $\hat\mu\pm1.959964\sqrt v$. This coverage is a nominal normal approximation using known iid variance, not a general-purpose confidence-interval estimator. Mean bias and squared error use separate twelve-test Holm families and 5,000 replicate bootstrap resamples for descriptive intervals. No primary squared-error test rejects. Only the original converter at $N=10000$ with increasing weights rejects the mean reference.

That selected cell was repeated using 20,000 new reservoirs and disjoint seeds after saving a protocol amendment. The follow-up uses its own three-test Holm family and a separately reported paired contrast; the selection and follow-up do not jointly claim a 5% error rate. Its results are:

| Method | Mean bias | SD of sample mean | 95% CI for bias | Holm $p$ | MSE/reference variance | Coverage |
|---|---:|---:|---|---:|---:|---:|
| corrected | 0.000060 | 0.007444 | [-0.000043, 0.000163] | 0.4818 | 0.9975 | 0.9493 |
| iid | -0.000062 | 0.007446 | [-0.000165, 0.000041] | 0.4818 | 0.9980 | 0.9514 |
| original | 0.000285 | 0.007441 | [0.000182, 0.000388] | 1.91e-07 | 0.9978 | 0.9502 |

The paired original-minus-repaired mean difference is 0.00022435 (95% CI [0.00018950, 0.00025920]; two-sided $p=2.34\times10^{-36}$). The original absolute bias is approximately 0.043% of the target mean, and about 0.038 sample-mean SDs. It is small on this scale. The paired change supports a conversion-specific effect in this configuration; absence of a repaired mean rejection does not prove zero bias.

The follow-up uncertainty estimates for the secondary outcomes are:

| Method | MSE/reference variance [95% bootstrap interval] | Coverage [95% Wilson interval] |
|---|---|---|
| corrected | 0.9975 [0.9782, 1.0169] | 0.9493 [0.9462, 0.9523] |
| iid | 0.9980 [0.9790, 1.0175] | 0.9514 [0.9483, 0.9543] |
| original | 0.9978 [0.9788, 1.0179] | 0.9502 [0.9471, 0.9531] |

These marginal intervals were added during manuscript preparation, using 5,000 replicate bootstrap resamples for squared error. They are descriptive, are not adjusted for multiplicity, and do not constitute an equivalence test or include uncertainty from selecting the follow-up configuration.

The observed MSE ratios remain close to one and nominal coverage close to 95%; substantial degradation of these quantities is not established. A distributional defect can therefore be detectable while a selected aggregate estimator remains comparatively insensitive. The practical effect therefore depends on the estimator and population. Across primary and follow-up runs there are 32,000 freshly built reservoirs, 64,000 conversion outputs and 32,000 iid control outputs; the two outputs per reservoir are not independent reservoir replicates.

## S8. Dependence on reservoir fraction and weight direction

A fixed follow-on grid uses $N=10000$, $m\in\{100,500,1000,2000\}$, and weights $1$, $i$, or $N+1-i$. Its twelve configurations each contain 5,000 freshly built reservoirs, separately reseeded original and repaired conversion queries, and an iid categorical control. There are 180,000 output records on 60,000 reservoirs plus 60,000 controls. Configurations use disjoint seed ranges. The protocol and sampler-script hashes were saved locally before execution; this is a review-motivated extension, not a public preregistration. Earlier records are not pooled into this grid.

The primary contrast is $d_r=\hat\mu_{r,\mathrm{original}}-\hat\mu_{r,\mathrm{repaired}}$. Two-sided paired tests use Holm adjustment over twelve contrasts. The family intervals are $\bar d\pm t_{1-0.05/(2\cdot12),4999}s_d/\sqrt{5000}$, giving Bonferroni simultaneous coverage of at least 95% under the interval assumptions. Bias-to-reference tests form a separate family of 36 method/configuration tests. MSE and nominal coverage remain secondary descriptive outcomes.

![Bias by reservoir fraction](supporting-evidence/stage7/bias-ratio-sweep.png)

Supplementary figure. All twelve paired normalized-mean differences with Bonferroni family intervals. Positive values indicate a larger original estimate. Weight direction refers to association with item label, not a change in the target weight definition.

| Weight profile | $m/N$ | Original minus repaired | SD of paired difference | Simultaneous interval | Holm $p$ | $d_z$ | $\Delta_{80}$ |
|---|---:|---:|---:|---|---:|---:|---:|
| decreasing | 0.01 | -0.000045 | 0.003194 | [-0.000175, 0.000084] | 1 | -0.014 | 1.67e-04 |
| decreasing | 0.05 | -0.000045 | 0.002659 | [-0.000153, 0.000063] | 1 | -0.017 | 1.39e-04 |
| decreasing | 0.1 | -0.000185 | 0.002597 | [-0.000291, -0.000080] | 4.217e-06 | -0.071 | 1.36e-04 |
| decreasing | 0.2 | -0.000984 | 0.002503 | [-0.001086, -0.000883] | $<10^{-100}$ | -0.393 | 1.31e-04 |
| increasing | 0.01 | 0.000008 | 0.003265 | [-0.000124, 0.000141] | 1 | 0.003 | 1.71e-04 |
| increasing | 0.05 | 0.000034 | 0.002638 | [-0.000073, 0.000141] | 1 | 0.013 | 1.38e-04 |
| increasing | 0.1 | 0.000236 | 0.002493 | [0.000135, 0.000337] | 2.259e-10 | 0.095 | 1.31e-04 |
| increasing | 0.2 | 0.000968 | 0.002449 | [0.000869, 0.001067] | $<10^{-100}$ | 0.395 | 1.28e-04 |
| uniform | 0.01 | 0.000010 | 0.003622 | [-0.000137, 0.000157] | 1 | 0.003 | 1.90e-04 |
| uniform | 0.05 | -0.000009 | 0.003097 | [-0.000134, 0.000117] | 1 | -0.003 | 1.62e-04 |
| uniform | 0.1 | -0.000019 | 0.002975 | [-0.000139, 0.000102] | 1 | -0.006 | 1.56e-04 |
| uniform | 0.2 | -0.000051 | 0.002910 | [-0.000169, 0.000067] | 1 | -0.017 | 1.53e-04 |

Here $d_z$ standardizes the paired intervention difference, not the original estimator's bias. At fraction 0.2 it is approximately $-0.393$ and $0.395$ for decreasing and increasing weights; at 0.1 it is $-0.071$ and $0.095$. With this many replicates, a small standardized effect can be estimated precisely. Across the grid, $\Delta_{80}$ ranges from $1.28\times10^{-4}$ to $1.90\times10^{-4}$ on the normalized-mean scale. This modeled detection threshold does not bound effects in cells that did not reject. Full $t$ statistics and computed $p$ values are retained in the analysis files; very small table values are abbreviated for readability.

The paired tests reject a zero difference for increasing and decreasing weights at fractions 0.1 and 0.2, with opposite signs. They do not reject for either profile at 0.01 or 0.05, or for uniform weights at any tested fraction. Non-rejection is not equivalence. The four-point grid is consistent with a larger effect at the largest tested fraction; it does not establish a universal monotonic law.

At fraction 0.2, original mean bias is 0.001086 for increasing weights and −0.001030 for decreasing weights, with Holm-adjusted $p<10^{-39}$ in the separate 36-test family. None of the repaired or iid bias tests rejects. At fraction 0.1, the absolute-bias tests do not reject although the paired tests do. Pairing uses shared reservoir randomness to estimate the intervention difference more precisely; the bias tests instead compare each method with a fixed population target. The earlier 20,000-replicate follow-up also used a different sample size and test family. The complete results are reported.

The original MSE/reference-variance ratios at fraction 0.2 are 1.0346 (increasing) and 1.0618 (decreasing); corresponding nominal coverage is 0.9440 and 0.9420. Full marginal intervals are supplied in the CSV. The measured changes are modest and limited to the tested estimator and populations. The sign reversal is consistent with erroneous rank reuse interacting with the association between weights and labels. The experiment does not determine a general bias formula. Uniform aggregate means failed to detect the separately established distributional error.

## S9. Native timing: observed direction and uncertain magnitude

The preserved stage-4 design crosses $N\in\{10^6,10^7\}$, $m/N\in\{10^{-4},10^{-3},10^{-2},10^{-1}\}$, three weight sequences, three methods and two code versions, with 20 runs per cell (2,880 records). It uses Julia 1.12.1, one thread, an Apple M3, 16 GiB RAM and macOS 27.0.1. Weight generation and construction are excluded from Add; initialization performed by Add remains included. Full-stream warmup precedes randomized method/version order within each configuration/replicate. Seeds and original records are preserved. The protocol's initial total of 1,440 was an arithmetic error; the factorial grid was not changed.

All 960 raw paired SKIP/BIN and SKIP/EXPJ Add ratios per code version are below one (48 method/configuration comparisons, each with 20 pairs). All 48 corresponding geometric-mean ratios per version are also below one. Thus the corrections do not create the observed ranking. However, half the 48 SKIP version/configuration cells have maximum-to-minimum time exceeding 2.5 (maximum 5.473). One BIN cell also exceeds that threshold (5.144), so high variability is not exclusive to SKIP. The observed clusters cannot be attributed to a particular hardware mechanism from these records. No timestamps, CPU affinity or power-state traces were collected in stage 4. The geometric ratios describe this run; their magnitude cannot be treated as stable across execution conditions.

![Raw paired timing](supporting-evidence/stage5/timing-raw-ratios.png)

Supplementary figure. All repaired paired Add ratios, on shared axes. Horizontal black bars show medians. The complete CSV includes medians, quartiles and raw-pair provenance. Coincident observations may overlap. Ratios below one favour SKIP on this device and interface.

Exploratory sensitivity analysis uses circular block resampling [13], [14] of log ratios with block lengths $L\in\{1,2,4,5\}$ and 5,000 resamples. All 48 repaired comparisons retain upper 95% sensitivity limits below one at all four lengths. Two-sided sign tests reject the null that either side of a ratio of one is equally likely, within each 48-contrast version family. Their independence assumption remains vulnerable to serial dependence. With only 20 runs, block intervals depend on stationarity and block-length assumptions and cannot certify timing stability. Marginal sensitivity intervals are not simultaneous confidence intervals.

For repair/original Add ratios, all four block intervals lie within $[0.9,1.1]$ in only 6/24 SKIP configurations, 22/24 BIN configurations and 24/24 EXPJ configurations. This is an exploratory interval-containment criterion, not a preregistered equivalence test or a proof of equal speed. EXPJ Add is algorithmically unchanged and serves as a variability control. The earlier three statistically slower BIN contrasts correspond to only about 0.6–0.9% longer time; their practical importance is not established. The claim “repair has no performance cost” is unsupported.

BIN/SKIP Get returns a stored reference, whereas EXPJ sorts its heap and converts a sample. The preserved Get batches include wrapper/checksum overhead and do not measure allocation of independent output copies. No claim is made about nanosecond differences between reference-return methods. The earlier C++ materialized-output measurements are in Supplement S11. A new timing campaign with timestamps and host-state logging is needed to estimate transferable speedup magnitudes; repeating the same uninstrumented grid would not resolve the cause.

## S10. Isolated dependency replay

A fresh Python virtual environment and a new Julia depot were installed on the same host; Julia 1.12.1 and the saved Project/Manifest were used. Six selected Python outputs matched saved bytes: five exact-enumeration outputs and the estimator-follow-up summary. Three native CSVs also matched: the million-sample-per-method occupancy check and the nine-cell routine diagnostics before and after count correction. The latter native replays comprise 6.6 million output samples, with the fixed-reservoir limitation of the occupancy check retained. Hashes, dependency versions and installation logs are supplied. The first Python launcher mistakenly resolved the venv symlink to the base interpreter; correcting that path resolved the missing-package failure before the successful replay.

This is a same-host dependency-isolation check, not independent-machine validation, a complete historical pipeline rebuild, or a new timing benchmark. Package-download caches may have supplied wheels. The new ratio sweep ran in the previously validated Julia environment, separately from these replays. No claim of all-platform determinism is made.

A later portable runner checks eight outputs from seven Python scripts: the six earlier outputs plus two ratio-sweep summaries. All eight were byte-identical in the recorded same-host execution. The current runner reports byte identity separately from numerical agreement: exact output files require matching bytes; decimal CSVs require matching structure, identifiers and categorical values, with explicit absolute/relative tolerances for finite numbers. Probability columns use relative tolerance only. Cross-environment byte identity has not been established. An external audit reports small decimal differences, but its execution logs were unavailable for verification.

## S11. Independent implementation and retrieval

The earlier independent C++ experiment timed individual materialized Get operations and retained 16 zero-duration readings at small reservoir sizes. The replacement design times batches of 100 calls on independently initialized reservoirs. Across 720 batches and 72,000 calls, every measured batch duration was positive; the minimum was two microseconds. The inferential unit is one batch, not one call. Each configuration has 20 batches, and the summary includes means, sample SDs and Student-$t$ intervals.

![Batched retrieval](supporting-evidence/stage3/batched-retrieval.png)

Supplementary figure. Warm-cache materialized retrieval throughput for the independent C++ implementations. The measured batch includes temporary-vector destruction and a minimal observable checksum. The measurement concerns materialized outputs; the original interface returns a stored reference.

Stage 2 used 6,480,000 reservoirs in two correctness families, 1,440 primary processing measurements and 90 scale-extension measurements. These independent C++ measurements are not pooled with native Julia timings. The retained code, raw results and historical stage manifests are supplied; superseded manuscript drafts were excluded during package cleanup.

## S12. Expectation identity

For $K_t\sim\operatorname{Bin}(m,p_t)$ and $a_t=\Pr(K_t>0)$, $\mathbb E[K_t\mid K_t>0]=mp_t/a_t$. Thus an update-cost accounting of two event-level variates plus $K_t$ position draws gives $\mathbb E[X]=1+\sum_t(2a_t+mp_t)$, rather than multiplying the unconditional $mp_t$ by $a_t$ again. Since $a_t\leq mp_t$, the stated logarithmic upper-bound argument remains available under its original assumptions. This is a correction to the inspected preprint's intermediate expectation, not a disproof of its asymptotic bound or a verified claim about publisher-version wording. The original algebraic audit is supplied separately.

## S13. Post-audit diagnostics and enumeration costs

The paired $t$ approximation assumes independent reservoir replicates, finite variance and an adequately approximated sampling distribution of the mean difference; exact finite-sample $t$ inference would additionally require normal differences. Post-audit diagnostics give maximum absolute sample skewness 0.083 and excess kurtosis up to 2.487 at fraction 0.01, with absolute excess kurtosis at most 0.430 otherwise. At 5,000 replicates, these shape diagnostics support the sampling approximation. Independence of pseudorandom streams remains an assumption.

We report the paired standardized difference $d_z=\bar d/s_d$. Detection sensitivity uses $\alpha_B=0.05/12$ and $c=t_{1-\alpha_B/2,4999}$. We solve $\Pr(|T_{4999,\lambda}|>c)=0.8$ and report $\Delta_{80}=\lambda s_d/\sqrt{5000}$. The resulting threshold is a post-audit sensitivity estimate conditional on the observed SD and noncentral-$t$ model. It was not used to plan sample size or define equivalence. The fixed Bonferroni cutoff also differs from the adaptive Holm procedure.

Here $d_z$ standardizes the paired intervention difference, not the original estimator's bias. At fraction 0.2 it is approximately $-0.393$ and $0.395$ for decreasing and increasing weights; at 0.1 it is $-0.071$ and $0.095$. With this many replicates, a small standardized effect can be estimated precisely. Across the grid, $\Delta_{80}$ ranges from $1.28\times10^{-4}$ to $1.90\times10^{-4}$ on the normalized-mean scale. This modeled detection threshold does not bound effects in cells that did not reject. Full $t$ statistics and computed $p$ values are retained in the analysis files; very small table values are abbreviated for readability.

Exact enumeration is restricted to small cases and excludes rational-arithmetic bit costs from the following operation counts. In `exact_grid.py`, the source converter has $m!$ rank-choice leaves; count construction and sorting at each leaf give a conservative $\mathcal O(m\log(m)\,m!)$ bound, with $\mathcal O(m\,p(m)+m^2)$ storage for partition probabilities and recursive lists, where $p(m)$ is the number of integer partitions. The grid uses $m\leq8$.

The fixed four-label `exact_audit.py` explicitly visits $4^3$ converter paths and $4^4$ iid reference paths. Generalizing this exhaustive labelled reference to $N,m$ would require $N^m$ paths, so the converter-only count is not the whole program's cost.

The weighted program `exact_weighted_conversion.py` additionally enumerates $N!$ key orders. Its conversion phase has conservative cost $\mathcal O(N!(N+m\,m!))$; building the full product-law reference and count-vector dictionaries in the implemented loops adds $\mathcal O(NmN^m)$. Total storage is conservatively $\mathcal O(NN^m+N^2+m^2)$, including output-state dictionaries, permutation state and recursive lists. Those runs are limited to $N\leq5$, $m\leq N$; the eight-draw bound of the equal-weight grid does not apply to this program. These costs concern audit enumeration, not the production reservoir algorithms.

The reproducible diagnostic source and outputs are in `supporting-evidence/stage8/`. No new reservoir samples or timing measurements were generated for this revision.
