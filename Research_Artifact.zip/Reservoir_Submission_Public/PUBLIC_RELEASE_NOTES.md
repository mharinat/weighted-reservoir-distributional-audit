# Public release preparation

Scientific tables, mathematical results and raw numerical data are unchanged from author-reviewed version 11. Submission labels replace internal review labels. Correspondence, internal reviewer reports and obsolete report builders are excluded. Historical stage README pointers were updated to the current manuscript. Historical manifests are provenance only, not current-release checksums.

Installation and execution logs are retained to support the dependency-isolation record. User-directory names in the following logs were replaced by REDACTED; numerical data and scientific code were not altered:

- supporting-evidence/stage7/python-install.log

The selected analysis replay was repeated from this public-release directory and passed all eight output comparisons. No new native samples or timings were generated.
